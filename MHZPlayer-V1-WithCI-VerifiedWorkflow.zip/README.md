# MHZ PLAYER — V1 Final Review

This package is the final-review candidate after Steps 1–6:
- Videos library: scan/refresh, folders, filters and sorting
- Audio library: songs, albums, artists, artwork and playback
- Video player: playback controls, volume, brightness, fullscreen, speed, subtitles and PiP
- Audio player: artwork, progress, playback controls, shuffle/repeat, favorites, queue, lyrics and sleep timer
- Favorites and Recently Played: persistent local history/favorites
- Playlists: create, rename, delete, add/remove media and play/shuffle
- Background audio: Media3 MediaSession with lock-screen/system media controls

Final-review fixes in this package include improved audio-player state observation so favorite/lyrics collectors are not recreated on every playback-position update, lyrics follow track changes, and the synced-lyrics list is constrained to avoid an unbounded Compose LazyColumn.

Build note: APK compilation was not verified in this environment because the Android SDK/Gradle wrapper is not available here.

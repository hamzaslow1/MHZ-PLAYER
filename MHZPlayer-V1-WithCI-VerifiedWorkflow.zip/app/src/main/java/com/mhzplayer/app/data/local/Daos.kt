package com.mhzplayer.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY addedAtMillis DESC")
    fun observeAll(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE mediaId = :mediaId AND type = :type)")
    fun observeIsFavorite(mediaId: Long, type: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE mediaId = :mediaId AND type = :type")
    suspend fun remove(mediaId: Long, type: String)

    @Query("SELECT COUNT(*) FROM favorites")
    fun observeCount(): Flow<Int>
}

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAtMillis DESC")
    fun observeAll(): Flow<List<PlaylistEntity>>

    @Insert
    suspend fun createPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :newName WHERE playlistId = :playlistId")
    suspend fun rename(playlistId: Long, newName: String)

    @Query("DELETE FROM playlists WHERE playlistId = :playlistId")
    suspend fun delete(playlistId: Long)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId")
    suspend fun clearItems(playlistId: Long)

    @Query("SELECT * FROM playlist_items WHERE playlistId = :playlistId ORDER BY position ASC")
    fun observeItems(playlistId: Long): Flow<List<PlaylistItemEntity>>

    @Query("SELECT COUNT(*) FROM playlist_items WHERE playlistId = :playlistId")
    fun observeItemCount(playlistId: Long): Flow<Int>

    @Query("SELECT COALESCE(MAX(position), -1) FROM playlist_items WHERE playlistId = :playlistId")
    suspend fun maxPosition(playlistId: Long): Int

    @Query("UPDATE playlist_items SET position = :position WHERE playlistId = :playlistId AND mediaId = :mediaId AND type = :type")
    suspend fun updatePosition(playlistId: Long, mediaId: Long, type: String, position: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addItem(item: PlaylistItemEntity)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId AND mediaId = :mediaId AND type = :type")
    suspend fun removeItem(playlistId: Long, mediaId: Long, type: String)

    @Query("SELECT COUNT(*) FROM playlists")
    fun observeCount(): Flow<Int>
}

/**
 * Declared as an abstract class (not an interface) so [recordPlay] can be a real
 * `@Transaction` method that calls the other abstract DAO methods below it — this
 * avoids relying on SQLite's `ON CONFLICT ... DO UPDATE` (UPSERT) syntax, which was
 * only added in SQLite 3.24 and isn't available on the Android 7.0–8.1 (API 24–27)
 * devices this app's minSdk still supports.
 */
@Dao
abstract class RecentlyPlayedDao {
    @Query("SELECT * FROM recently_played ORDER BY playedAtMillis DESC LIMIT :limit")
    abstract fun observeRecent(limit: Int = 20): Flow<List<RecentlyPlayedEntity>>

    @Query("SELECT * FROM recently_played ORDER BY playCount DESC LIMIT :limit")
    abstract fun observeFrequent(limit: Int = 20): Flow<List<RecentlyPlayedEntity>>

    @Query("DELETE FROM recently_played")
    abstract suspend fun clearAll()

    @Query("UPDATE recently_played SET playedAtMillis = :playedAtMillis, playCount = playCount + 1 WHERE mediaId = :mediaId AND type = :type")
    abstract suspend fun touch(mediaId: Long, type: String, playedAtMillis: Long): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insertIfAbsent(entity: RecentlyPlayedEntity): Long

    @Transaction
    open suspend fun recordPlay(mediaId: Long, type: String, playedAtMillis: Long) {
        val rowsUpdated = touch(mediaId, type, playedAtMillis)
        if (rowsUpdated == 0) {
            insertIfAbsent(RecentlyPlayedEntity(mediaId, type, playedAtMillis, 1))
        }
    }
}

@Dao
interface QueueDao {
    @Query("SELECT * FROM queue_items ORDER BY position ASC")
    fun observeQueue(): Flow<List<QueueItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<QueueItemEntity>)

    @Query("DELETE FROM queue_items")
    suspend fun clear()

    @Delete
    suspend fun remove(item: QueueItemEntity)
}

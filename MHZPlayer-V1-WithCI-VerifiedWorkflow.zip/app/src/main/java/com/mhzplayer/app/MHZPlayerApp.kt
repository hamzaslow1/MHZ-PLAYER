package com.mhzplayer.app

import android.app.Application

class MHZPlayerApp : Application() {
    val locator by lazy { ServiceLocator.get(this) }
}

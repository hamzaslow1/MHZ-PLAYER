package com.mhzplayer.app

import android.content.Context
import com.mhzplayer.app.data.local.AppDatabase
import com.mhzplayer.app.data.local.SettingsDataStore
import com.mhzplayer.app.data.repository.FavoritesRepository
import com.mhzplayer.app.data.repository.LyricsRepository
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.data.repository.PlaylistRepository
import com.mhzplayer.app.data.repository.RecentlyPlayedRepository
import com.mhzplayer.app.data.repository.SettingsRepository
import com.mhzplayer.app.playback.PlayerController

/**
 * Lightweight manual service locator — keeps the project dependency-free (no Hilt/Dagger
 * setup required) while still giving every ViewModel a single shared instance of each
 * repository, so Favorites/Playlists/Library stay in sync across all screens.
 */
class ServiceLocator private constructor(context: Context) {
    private val appContext = context.applicationContext
    private val db by lazy { AppDatabase.getInstance(appContext) }
    private val settingsStore by lazy { SettingsDataStore(appContext) }

    val mediaRepository by lazy { MediaRepository(appContext) }
    val favoritesRepository by lazy { FavoritesRepository(db.favoriteDao()) }
    val playlistRepository by lazy { PlaylistRepository(db.playlistDao()) }
    val recentlyPlayedRepository by lazy { RecentlyPlayedRepository(db.recentlyPlayedDao()) }
    val settingsRepository by lazy { SettingsRepository(settingsStore) }
    val lyricsRepository by lazy { LyricsRepository() }
    val playerController by lazy { PlayerController(appContext) }

    companion object {
        @Volatile private var INSTANCE: ServiceLocator? = null
        fun get(context: Context): ServiceLocator =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: ServiceLocator(context).also { INSTANCE = it }
            }
    }
}

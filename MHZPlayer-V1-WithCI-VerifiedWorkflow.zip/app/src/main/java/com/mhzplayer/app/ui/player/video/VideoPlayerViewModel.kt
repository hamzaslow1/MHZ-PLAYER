package com.mhzplayer.app.ui.player.video

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.exoplayer.ExoPlayer
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.data.repository.RecentlyPlayedRepository
import com.mhzplayer.app.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class VideoPlayerUiState(
    val item: MediaItem? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val volume: Float = 1.0f,
    val subtitlesEnabled: Boolean = true,
    val error: String? = null,
)

/**
 * Phase 7 — real video playback for on-device files. Owns a dedicated ExoPlayer instance
 * (video uses its own PlayerView surface, unlike audio which plays through the background
 * MediaSessionService) and remembers/restores position when the setting is enabled (Section 26).
 */
class VideoPlayerViewModel(
    context: Context,
    private val mediaRepository: MediaRepository,
    private val recentlyPlayedRepository: RecentlyPlayedRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build()

    private val _state = MutableStateFlow(VideoPlayerUiState())
    val state: StateFlow<VideoPlayerUiState> = _state.asStateFlow()

    private val lastPositions = mutableMapOf<Long, Long>()

    init {
        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _state.value = _state.value.copy(isPlaying = isPlaying)
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                // Never crash on unsupported/deleted/corrupt files (Section 29).
                _state.value = _state.value.copy(error = "Ba a iya buɗe wannan bidiyon ba.")
            }
        })
    }

    fun play(mediaId: Long) {
        val item = mediaRepository.video.value.find { it.id == mediaId } ?: return
        _state.value = _state.value.copy(item = item, error = null, durationMs = item.durationMs)
        exoPlayer.setMediaItem(Media3Item.fromUri(item.uriString))
        exoPlayer.prepare()

        viewModelScope.launch {
            val shouldRemember = settingsRepository.rememberVideoPosition.first()
            val startAt = if (shouldRemember) lastPositions[mediaId] ?: 0L else 0L
            if (startAt > 0) exoPlayer.seekTo(startAt)
            exoPlayer.playWhenReady = true
        }
        viewModelScope.launch { recentlyPlayedRepository.recordPlay(mediaId, MediaType.VIDEO) }
    }

    fun togglePlayPause() {
        exoPlayer.playWhenReady = !exoPlayer.playWhenReady
    }

    fun seekBy(deltaMs: Long) {
        val target = (exoPlayer.currentPosition + deltaMs).coerceIn(0, exoPlayer.duration.coerceAtLeast(0))
        exoPlayer.seekTo(target)
    }

    fun seekTo(ms: Long) = exoPlayer.seekTo(ms)

    fun setSpeed(speed: Float) {
        exoPlayer.setPlaybackSpeed(speed)
        _state.value = _state.value.copy(playbackSpeed = speed)
    }

    fun setVolume(volume: Float) {
        val value = volume.coerceIn(0f, 1f)
        exoPlayer.volume = value
        _state.value = _state.value.copy(volume = value)
    }

    fun changeVolume(delta: Float) = setVolume(exoPlayer.volume + delta)

    fun toggleSubtitles() {
        val enabled = !_state.value.subtitlesEnabled
        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, !enabled)
            .build()
        _state.value = _state.value.copy(subtitlesEnabled = enabled)
    }

    fun savePositionAndPause() {
        val id = _state.value.item?.id ?: return
        lastPositions[id] = exoPlayer.currentPosition
        exoPlayer.pause()
    }

    override fun onCleared() {
        exoPlayer.release()
        super.onCleared()
    }
}

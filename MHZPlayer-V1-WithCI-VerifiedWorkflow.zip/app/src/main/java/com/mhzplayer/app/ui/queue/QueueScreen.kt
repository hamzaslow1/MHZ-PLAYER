package com.mhzplayer.app.ui.queue

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzRed
import com.mhzplayer.app.ui.theme.MhzTextSecondary

/** Section 14 — real playback queue: view, play another item, remove, clear. */
@Composable
fun QueueScreen(
    queue: List<MediaItem>,
    currentItem: MediaItem?,
    onPlayIndex: (Int) -> Unit,
    onRemove: (Int) -> Unit,
    onClear: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Queue", style = MaterialTheme.typography.headlineMedium)
            if (queue.isNotEmpty()) TextButton(onClick = onClear) { Text("Clear All", color = MhzRed) }
        }

        if (queue.isEmpty()) {
            EmptyState(title = "Babu Queue", message = "Kunna media don ganin jerin waƙoƙi a nan.")
        } else {
            LazyColumn(modifier = Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(queue, key = { _, item -> "${item.type}-${item.id}" }) { index, item ->
                    val isCurrent = currentItem?.id == item.id && currentItem.type == item.type
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isCurrent) MhzRed.copy(alpha = 0.18f) else MhzCardElevated)
                            .clickable { onPlayIndex(index) }
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.DragHandle, contentDescription = null, tint = MhzTextSecondary)
                            Column(modifier = Modifier.padding(start = 10.dp)) {
                                Text(item.title, color = if (isCurrent) MhzRed else MaterialTheme.colorScheme.onBackground)
                                item.artist?.let { Text(it, color = MhzTextSecondary, style = MaterialTheme.typography.bodyMedium) }
                            }
                        }
                        IconButton(onClick = { onRemove(index) }) { Icon(Icons.Filled.Close, contentDescription = "Remove") }
                    }
                }
            }
        }
    }
}

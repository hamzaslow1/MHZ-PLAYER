package com.mhzplayer.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mhzplayer.app.data.model.LibraryFilter
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.ui.MhzViewModelFactory
import com.mhzplayer.app.ui.favorites.FavoritesScreen
import com.mhzplayer.app.ui.favorites.FavoritesViewModel
import com.mhzplayer.app.ui.recent.RecentlyPlayedViewModel
import com.mhzplayer.app.ui.recent.RecentlyPlayedScreen
import com.mhzplayer.app.ui.home.HomeScreen
import com.mhzplayer.app.ui.home.HomeViewModel
import com.mhzplayer.app.ui.library.LibraryScreen
import com.mhzplayer.app.ui.audio.AudioLibraryScreen
import com.mhzplayer.app.ui.audio.AudioLibraryViewModel
import com.mhzplayer.app.ui.library.LibraryViewModel
import com.mhzplayer.app.ui.onboarding.PermissionScreen
import com.mhzplayer.app.ui.player.audio.AudioPlayerScreen
import com.mhzplayer.app.ui.player.audio.AudioPlayerViewModel
import com.mhzplayer.app.ui.player.video.VideoPlayerScreen
import com.mhzplayer.app.ui.player.video.VideoPlayerViewModel
import com.mhzplayer.app.ui.playlist.PlaylistDetailScreen
import com.mhzplayer.app.ui.playlist.PlaylistDetailViewModel
import com.mhzplayer.app.ui.playlist.PlaylistsScreen
import com.mhzplayer.app.ui.playlist.PlaylistsViewModel
import com.mhzplayer.app.ui.queue.QueueScreen
import com.mhzplayer.app.ui.search.SearchScreen
import com.mhzplayer.app.ui.search.SearchViewModel
import com.mhzplayer.app.ui.settings.SettingsScreen
import com.mhzplayer.app.ui.settings.SettingsViewModel
import com.mhzplayer.app.ui.splash.SplashScreen

/**
 * The full navigation graph: Splash -> Permission -> Home, with the four bottom-nav
 * destinations plus modal-style pushes for Player, Queue, Favorites and Playlists —
 * mirroring the prototype's navigation structure (Section 27) without replacing it.
 */
@Composable
fun MhzNavGraph(
    onEnterPip: (androidx.media3.exoplayer.ExoPlayer) -> Unit = {},
    onToggleFullscreen: () -> Unit = {},
    onBrightness: (Float) -> Unit = {},
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val showBottomBar = currentRoute != null && bottomNavDestinations.any { currentRoute.startsWith(it.route.substringBefore("?")) } ||
        currentRoute == Destination.Home.route

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                MhzBottomNavBar(currentRoute = currentRoute) { dest ->
                    navController.navigate(dest.route) {
                        popUpTo(Destination.Home.route) { inclusive = false }
                        launchSingleTop = true
                    }
                }
            }
        },
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
    ) { padding ->
        NavHost(navController = navController, startDestination = Destination.Splash.route, modifier = Modifier.padding(padding)) {

            composable(Destination.Splash.route) {
                SplashScreen(onFinished = {
                    navController.navigate(Destination.Permission.route) { popUpTo(Destination.Splash.route) { inclusive = true } }
                })
            }

            composable(Destination.Permission.route) {
                PermissionScreen(onGranted = {
                    navController.navigate(Destination.Home.route) { popUpTo(Destination.Permission.route) { inclusive = true } }
                })
            }

            composable(Destination.Home.route) {
                val vm: HomeViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                HomeScreen(
                    state = state,
                    onOpenSearch = { navController.navigate(Destination.Search.route) },
                    onOpenLibrary = { type ->
                        val filter = when (type) { MediaType.AUDIO -> LibraryFilter.AUDIO; MediaType.VIDEO -> LibraryFilter.VIDEO; else -> LibraryFilter.ALL }
                        if (type == MediaType.AUDIO) navController.navigate(Destination.AudioLibrary.route) else navController.navigate(Destination.Library.withFilter(filter.name))
                    },
                    onOpenFavorites = { navController.navigate(Destination.Favorites.route) },
                    onOpenPlaylists = { navController.navigate(Destination.Playlists.route) },
                    onPlayMedia = { id, type -> navigateToPlayer(navController, id, type) },
                )
            }

            composable(
                Destination.Library.route,
                arguments = listOf(navArgument("filter") { type = NavType.StringType; defaultValue = LibraryFilter.ALL.name }),
            ) { entry ->
                val filterArg = entry.arguments?.getString("filter") ?: LibraryFilter.ALL.name
                val filter = runCatching { LibraryFilter.valueOf(filterArg) }.getOrDefault(LibraryFilter.ALL)
                val vm: LibraryViewModel = viewModel(factory = MhzViewModelFactory(context, libraryFilter = filter))
                val state by vm.state.collectAsState()
                LibraryScreen(
                    state = state,
                    onFilterChange = vm::setFilter,
                    onRefresh = vm::refresh,
                    onOpenPlaylists = { navController.navigate(Destination.Playlists.route) },
                    onPlayMedia = { item -> navigateToPlayer(navController, item.id, item.type) },
                    onSortChange = vm::setSort,
                )
            }

            composable(Destination.AudioLibrary.route) {
                val vm: AudioLibraryViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                AudioLibraryScreen(
                    state = state,
                    onTabChange = vm::setTab,
                    onRefresh = vm::refresh,
                    onSort = vm::setSort,
                    onPlay = { navigateToPlayer(navController, it.id, MediaType.AUDIO) },
                    onShuffle = vm::shuffle,
                )
            }

            composable(Destination.Search.route) {
                val vm: SearchViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                SearchScreen(
                    state = state,
                    onQueryChange = vm::onQueryChange,
                    onSubmit = vm::commitToHistory,
                    onClear = vm::clearQuery,
                    onClearHistory = vm::clearHistory,
                    onHistoryClick = vm::onQueryChange,
                    onPlayMedia = { item -> navigateToPlayer(navController, item.id, item.type) },
                )
            }

            composable(Destination.Settings.route) {
                val vm: SettingsViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                SettingsScreen(
                    state = state,
                    onAutoplayChange = vm::setAutoplay,
                    onShuffleDefaultChange = vm::setShuffleDefault,
                    onRememberPositionChange = vm::setRememberVideoPosition,
                    onNotificationsChange = vm::setNotificationsEnabled,
                    onRefreshLibrary = vm::refreshLibrary,
                    onOpenAbout = {},
                    onExit = { (context as? android.app.Activity)?.finish() },
                )
            }

            composable(Destination.Favorites.route) {
                val vm: FavoritesViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                FavoritesScreen(state = state, onPlay = { item -> navigateToPlayer(navController, item.id, item.type) }, onClear = vm::clearAll)
            }

            composable(Destination.RecentlyPlayed.route) {
                val vm: RecentlyPlayedViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                RecentlyPlayedScreen(
                    items = state.items,
                    onPlay = { item -> navigateToPlayer(navController, item.id, item.type) },
                    onClear = vm::clearHistory,
                )
            }

            composable(Destination.Playlists.route) {
                val vm: PlaylistsViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                PlaylistsScreen(
                    state = state,
                    onCreate = vm::create,
                    onRename = vm::rename,
                    onDelete = vm::delete,
                    onOpen = { id -> navController.navigate(Destination.PlaylistDetail.of(id)) },
                )
            }

            composable(Destination.PlaylistDetail.route) { entry ->
                val playlistId = entry.arguments?.getString("playlistId")?.toLongOrNull() ?: 0L
                val vm: PlaylistDetailViewModel = viewModel(factory = MhzViewModelFactory(context, playlistId = playlistId))
                val state by vm.state.collectAsState()
                val locator = com.mhzplayer.app.ServiceLocator.get(context)
                PlaylistDetailScreen(
                    state = state,
                    onPlay = { item -> navigateToPlayer(navController, item.id, item.type) },
                    onPlayAll = {
                        if (state.items.isNotEmpty()) {
                            locator.playerController.playQueue(state.items, 0)
                            navigateToPlayer(navController, state.items.first().id, state.items.first().type)
                        }
                    },
                    onShuffle = {
                        if (state.items.isNotEmpty()) {
                            locator.playerController.playQueue(state.items.shuffled(), 0)
                            navigateToPlayer(navController, state.items.first().id, state.items.first().type)
                        }
                    },
                    onAdd = vm::addItem,
                    onRemove = vm::removeItem,
                )
            }

            composable(Destination.AudioPlayer.route) { entry ->
                val mediaId = entry.arguments?.getString("mediaId")?.toLongOrNull() ?: return@composable
                val vm: AudioPlayerViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                androidx.compose.runtime.LaunchedEffect(mediaId) {
                    if (vm.state.value.playback.currentItem?.id != mediaId) vm.playFromLibrary(mediaId)
                }
                AudioPlayerScreen(
                    state = state,
                    onTogglePlayPause = vm::togglePlayPause,
                    onNext = vm::next,
                    onPrevious = vm::previous,
                    onSeek = vm::seekTo,
                    onToggleShuffle = vm::toggleShuffle,
                    onCycleRepeat = vm::cycleRepeat,
                    onToggleFavorite = vm::toggleFavorite,
                    onOpenQueue = { navController.navigate(Destination.Queue.route) },
                    onSetSleepTimer = vm::setSleepTimer,
                )
            }

            composable(Destination.VideoPlayer.route) { entry ->
                val mediaId = entry.arguments?.getString("mediaId")?.toLongOrNull() ?: return@composable
                val vm: VideoPlayerViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                androidx.compose.runtime.LaunchedEffect(mediaId) { vm.play(mediaId) }
                VideoPlayerScreen(
                    state = state,
                    exoPlayer = vm.exoPlayer,
                    onTogglePlayPause = vm::togglePlayPause,
                    onSeekBy = vm::seekBy,
                    onSeekTo = vm::seekTo,
                    onSetSpeed = vm::setSpeed,
                    onChangeVolume = vm::changeVolume,
                    onToggleSubtitles = vm::toggleSubtitles,
                    onToggleFullscreen = onToggleFullscreen,
                    onBrightness = onBrightness,
                    onEnterPip = { onEnterPip(vm.exoPlayer) },
                )
            }

            composable(Destination.Queue.route) {
                val vm: AudioPlayerViewModel = viewModel(factory = MhzViewModelFactory(context))
                val state by vm.state.collectAsState()
                QueueScreen(
                    queue = state.playback.queue,
                    currentItem = state.playback.currentItem,
                    onPlayIndex = vm::playQueueIndex,
                    onRemove = vm::removeFromQueue,
                    onClear = vm::clearQueue,
                )
            }
        }
    }
}

private fun navigateToPlayer(navController: NavHostController, mediaId: Long, type: MediaType) {
    if (type == MediaType.AUDIO) {
        navController.navigate(Destination.AudioPlayer.of(mediaId))
    } else {
        navController.navigate(Destination.VideoPlayer.of(mediaId))
    }
}

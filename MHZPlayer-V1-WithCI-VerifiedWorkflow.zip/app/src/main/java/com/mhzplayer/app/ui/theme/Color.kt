package com.mhzplayer.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand
val MhzRed = Color(0xFFE31C1C)
val MhzRedDark = Color(0xFFB71414)

// Backgrounds
val MhzBackground = Color(0xFF0A0708)
val MhzSurface = Color(0xFF141014)
val MhzSurfaceVariant = Color(0xFF171012)
val MhzCardElevated = Color(0xFF2A0E0E)

// Text
val MhzTextPrimary = Color(0xFFFFFFFF)
val MhzTextSecondary = Color(0xFFB0AAAA)
val MhzTextDisabled = Color(0xFF6E6668)

// Quick access accents
val MhzAccentVideo = Color(0xFFE31C1C)
val MhzAccentAudio = Color(0xFF6C5CE7)
val MhzAccentFavorites = Color(0xFFE84393)
val MhzAccentPlaylists = Color(0xFF17A589)

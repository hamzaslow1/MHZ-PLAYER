package com.mhzplayer.app.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class LyricLine(val timeMs: Long, val text: String)
sealed class LyricsResult {
    object None : LyricsResult()
    data class PlainText(val text: String) : LyricsResult()
    data class Synced(val lines: List<LyricLine>) : LyricsResult()
}

/**
 * Section 16 — "Kalmomi" lyrics. Looks for a local .lrc (synced) or .txt (plain) file next
 * to the audio file, sharing its file name. Never fabricates lyrics — if nothing is found,
 * the UI shows "Babu Kalmomi".
 */
class LyricsRepository {

    suspend fun loadFor(audioFilePath: String?): LyricsResult = withContext(Dispatchers.IO) {
        if (audioFilePath == null) return@withContext LyricsResult.None
        val base = File(audioFilePath).nameWithoutExtension
        val dir = File(audioFilePath).parentFile ?: return@withContext LyricsResult.None

        val lrc = File(dir, "$base.lrc")
        if (lrc.exists()) return@withContext parseLrc(lrc.readText())

        val txt = File(dir, "$base.txt")
        if (txt.exists()) return@withContext LyricsResult.PlainText(txt.readText())

        LyricsResult.None
    }

    private fun parseLrc(content: String): LyricsResult {
        val lineRegex = Regex("""\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?]""")
        val lines = mutableListOf<LyricLine>()
        content.lines().forEach { raw ->
            val matches = lineRegex.findAll(raw)
            val text = raw.replace(lineRegex, "").trim()
            matches.forEach { m ->
                val minutes = m.groupValues[1].toLong()
                val seconds = m.groupValues[2].toLong()
                val millis = m.groupValues[3].let { if (it.isEmpty()) 0L else it.padEnd(3, '0').toLong() }
                val timeMs = minutes * 60_000 + seconds * 1000 + millis
                if (text.isNotEmpty()) lines += LyricLine(timeMs, text)
            }
        }
        return if (lines.isEmpty()) LyricsResult.None else LyricsResult.Synced(lines.sortedBy { it.timeMs })
    }
}

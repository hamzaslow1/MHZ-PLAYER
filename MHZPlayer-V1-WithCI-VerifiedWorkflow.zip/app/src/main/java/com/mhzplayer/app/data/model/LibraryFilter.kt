package com.mhzplayer.app.data.model

/** Library / Search category filter — mirrors "Duka / Video / Audio / Playlist" in the prototype. */
enum class LibraryFilter { ALL, VIDEO, AUDIO, PLAYLIST }

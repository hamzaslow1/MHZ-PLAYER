package com.mhzplayer.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.components.MediaCard
import com.mhzplayer.app.ui.components.PrimaryButton
import com.mhzplayer.app.ui.components.QuickAccessCard
import com.mhzplayer.app.ui.components.SectionHeader
import com.mhzplayer.app.ui.theme.MhzAccentAudio
import com.mhzplayer.app.ui.theme.MhzAccentFavorites
import com.mhzplayer.app.ui.theme.MhzAccentPlaylists
import com.mhzplayer.app.ui.theme.MhzAccentVideo
import com.mhzplayer.app.ui.theme.MhzRed

@Composable
fun HomeScreen(
    state: HomeUiState,
    onOpenSearch: () -> Unit,
    onOpenLibrary: (MediaType?) -> Unit,
    onOpenFavorites: () -> Unit,
    onOpenPlaylists: () -> Unit,
    onPlayMedia: (Long, MediaType) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        // Header: brand + search + notifications
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = MhzRed, fontWeight = FontWeight.Bold)) { append("MHZ ") }
                    withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Bold)) { append("PLAYER") }
                },
                style = MaterialTheme.typography.titleLarge,
            )
            Row {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = Color.White,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onOpenSearch() }
                        .padding(6.dp)
                        .padding(end = 6.dp),
                )
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(22.dp)) {
            item {
                // Hero card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.7f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(MhzRed.copy(alpha = 0.55f), Color(0xFF2A0E0E)))),
                ) {
                    Column(modifier = Modifier.padding(20.dp).align(Alignment.CenterStart)) {
                        Text(
                            "Enjoy Your\nFavorite Media",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                        )
                        Text(
                            "Videos, Music and More…",
                            color = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.padding(top = 6.dp, bottom = 14.dp),
                        )
                        PrimaryButton(text = "Explore Now", onClick = { onOpenLibrary(null) })
                    }
                }
            }

            item { SectionHeader(title = "Quick Access", onSeeAll = { onOpenLibrary(null) }) }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height(180.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item { QuickAccessCard(Icons.Filled.Videocam, "Videos", state.videoCount, "files", MhzAccentVideo) { onOpenLibrary(MediaType.VIDEO) } }
                    item { QuickAccessCard(Icons.Filled.MusicNote, "Audio", state.audioCount, "files", MhzAccentAudio) { onOpenLibrary(MediaType.AUDIO) } }
                    item { QuickAccessCard(Icons.Filled.Favorite, "Favorites", state.favoritesCount, "items", MhzAccentFavorites) { onOpenFavorites() } }
                    item { QuickAccessCard(Icons.Filled.PlaylistPlay, "Playlists", state.playlistsCount, "playlists", MhzAccentPlaylists) { onOpenPlaylists() } }
                }
            }

            item { SectionHeader(title = "Recently Played") }
            item {
                if (state.recentlyPlayed.isEmpty()) {
                    EmptyState(title = "Babu Tarihi", message = "Media da ka kunna kwanan nan za su bayyana a nan.")
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(state.recentlyPlayed, key = { "${it.type}-${it.id}" }) { item ->
                            MediaCard(item = item, modifier = Modifier.width(160.dp)) { onPlayMedia(item.id, item.type) }
                        }
                    }
                }
            }

            item { SectionHeader(title = "Recommended For You") }
            item {
                if (state.recommended.isEmpty()) {
                    EmptyState(title = "Babu Shawarwari Tukuna", message = "Bincika laburare naka don ganin shawarwari a nan.")
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(state.recommended, key = { "rec-${it.type}-${it.id}" }) { item ->
                            MediaCard(item = item, modifier = Modifier.width(160.dp)) { onPlayMedia(item.id, item.type) }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

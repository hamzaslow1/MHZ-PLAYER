package com.mhzplayer.app.data.repository

import android.content.Context
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.model.SortField
import com.mhzplayer.app.data.model.SortOption
import com.mhzplayer.app.data.model.SortOrder
import com.mhzplayer.app.data.scanner.MediaScanner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Single source of truth for the device's real media library (Phase 3 + 4).
 * Holds an in-memory cache populated by [refresh]; screens read from the
 * exposed StateFlows so "Refresh Library" updates every consumer at once.
 */
class MediaRepository(context: Context) {

    private val scanner = MediaScanner(context)

    private val _audio = MutableStateFlow<List<MediaItem>>(emptyList())
    val audio: StateFlow<List<MediaItem>> = _audio.asStateFlow()

    private val _video = MutableStateFlow<List<MediaItem>>(emptyList())
    val video: StateFlow<List<MediaItem>> = _video.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _lastScanError = MutableStateFlow<String?>(null)
    val lastScanError: StateFlow<String?> = _lastScanError.asStateFlow()

    suspend fun refresh() {
        _isScanning.value = true
        _lastScanError.value = null
        try {
            _audio.value = scanner.scanAudio()
            _video.value = scanner.scanVideo()
        } catch (t: Throwable) {
            // Never crash on a scan failure (Section 29) — surface a friendly message instead.
            _lastScanError.value = "Ba a iya duba media ba. Gwada sake."
        } finally {
            _isScanning.value = false
        }
    }

    fun findById(id: Long, type: MediaType): MediaItem? =
        if (type == MediaType.AUDIO) _audio.value.find { it.id == id } else _video.value.find { it.id == id }

    fun search(query: String): List<MediaItem> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        return (_audio.value + _video.value).filter { item ->
            item.title.lowercase().contains(q) ||
                item.artist?.lowercase()?.contains(q) == true ||
                item.album?.lowercase()?.contains(q) == true ||
                item.filePath?.lowercase()?.contains(q) == true
        }
    }

    fun sorted(items: List<MediaItem>, option: SortOption): List<MediaItem> {
        val comparator = when (option.field) {
            SortField.NAME -> compareBy<MediaItem> { it.title.lowercase() }
            SortField.DATE_ADDED -> compareBy { it.dateAddedSeconds }
            SortField.DURATION -> compareBy { it.durationMs }
            SortField.SIZE -> compareBy { it.sizeBytes }
            SortField.ARTIST -> compareBy { it.artist?.lowercase() ?: "" }
            SortField.ALBUM -> compareBy { it.album?.lowercase() ?: "" }
        }
        val sorted = items.sortedWith(comparator)
        return if (option.order == SortOrder.DESCENDING) sorted.reversed() else sorted
    }

    fun foldersFor(items: List<MediaItem>) =
        items.groupBy { it.folderName ?: "Unknown" }
            .map { (name, files) -> name to files.size }
            .sortedBy { it.first.lowercase() }
}

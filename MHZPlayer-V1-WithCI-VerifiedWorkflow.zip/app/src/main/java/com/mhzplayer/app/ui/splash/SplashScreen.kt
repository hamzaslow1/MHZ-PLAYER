package com.mhzplayer.app.ui.splash

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.ui.theme.MhzBackground
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzRed
import com.mhzplayer.app.ui.theme.MhzTextSecondary
import kotlinx.coroutines.delay

/**
 * Splash screen (Section 4): logo, MHZ PLAYER wordmark, tagline, and a short loading
 * animation, then automatically continues to permission check / Home.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1600)
        onFinished()
    }

    val transition = rememberInfiniteTransition(label = "splash-loading")
    val progress by transition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "progress",
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(listOf(MhzRed.copy(alpha = 0.25f), MhzBackground))
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Brand mark: red triangular play symbol with a white "M"
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(MhzRed),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.PlayArrow,
                    contentDescription = "MHZ PLAYER",
                    tint = Color.White,
                    modifier = Modifier.size(56.dp),
                )
            }

            Box(modifier = Modifier.padding(top = 28.dp)) {
                Text(
                    buildAnnotatedBrand(),
                    style = MaterialTheme.typography.headlineLarge,
                )
            }

            Text(
                "Your Videos & Music",
                color = MhzTextSecondary,
                modifier = Modifier.padding(top = 10.dp),
            )
            Text("Anywhere, Anytime", color = MhzTextSecondary)

            Box(
                modifier = Modifier
                    .padding(top = 40.dp)
                    .size(width = 140.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MhzCardElevated),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(fraction = progress)
                        .clip(RoundedCornerShape(2.dp))
                        .background(MhzRed),
                )
            }
        }
    }
}

@Composable
private fun buildAnnotatedBrand() = androidx.compose.ui.text.buildAnnotatedString {
    withStyle(androidx.compose.ui.text.SpanStyle(color = MhzRed, fontWeight = FontWeight.Bold)) { append("MHZ ") }
    withStyle(androidx.compose.ui.text.SpanStyle(color = Color.White, fontWeight = FontWeight.Bold)) { append("PLAYER") }
}

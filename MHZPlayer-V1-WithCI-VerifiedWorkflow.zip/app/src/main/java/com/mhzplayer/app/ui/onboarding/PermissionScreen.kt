package com.mhzplayer.app.ui.onboarding

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mhzplayer.app.ui.components.PrimaryButton
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzTextSecondary
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState

/**
 * Section 5 — first-launch permission explanation + request flow. Explains clearly why
 * media access is needed, lets the user allow/deny, and offers "Open Settings" if they
 * previously denied — never crashes if access is refused.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PermissionScreen(onGranted: () -> Unit) {
    val context = LocalContext.current
    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        listOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
    } else {
        listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    val showSettings = remember { mutableStateOf(false) }
    val permissionState = rememberMultiplePermissionsState(permissions) { results ->
        if (results.values.all { it }) {
            onGranted()
        } else {
            showSettings.value = true
        }
    }
    LaunchedEffect(permissionState.allPermissionsGranted) {
        if (permissionState.allPermissionsGranted) onGranted()
    }

    if (permissionState.allPermissionsGranted) return

    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier.size(84.dp).clip(RoundedCornerShape(20.dp)).background(MhzCardElevated),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.FolderOff, contentDescription = null, tint = MhzTextSecondary, modifier = Modifier.size(40.dp))
            }
            Text(
                "Babu Damar Shiga Media",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 20.dp),
            )
            Text(
                "Allow MHZ PLAYER to access your music and videos.",
                color = MhzTextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp, start = 12.dp, end = 12.dp),
            )
            PrimaryButton(
                text = "Allow Access",
                modifier = Modifier.padding(top = 24.dp),
                onClick = {
                    permissionState.launchMultiplePermissionRequests()
                },
            )
            if (showSettings.value) {
                Text(
                    "Open Settings",
                    color = MhzTextSecondary,
                    modifier = Modifier.padding(top = 16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
                androidx.compose.foundation.layout.Spacer(Modifier.size(4.dp))
                PrimaryButton(text = "Open Settings", onClick = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", context.packageName, null)
                    }
                    context.startActivity(intent)
                })
            }
        }
    }
}

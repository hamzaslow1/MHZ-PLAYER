package com.mhzplayer.app.data.model

/** The type of a scanned media file. */
enum class MediaType { AUDIO, VIDEO }

/**
 * A single audio or video file discovered on the device via MediaStore.
 * This is the core real-media model used everywhere in the app (Library,
 * Search, Player, Favorites, Playlists, Recently Played) — never fake data.
 */
data class MediaItem(
    val id: Long,
    val uriString: String,
    val title: String,
    val artist: String? = null,
    val album: String? = null,
    val type: MediaType,
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val dateAddedSeconds: Long = 0L,
    val mimeType: String? = null,
    val filePath: String? = null,
    val folderName: String? = null,
    val albumArtUri: String? = null,
)

enum class SortField { NAME, DATE_ADDED, DURATION, SIZE, ARTIST, ALBUM }
enum class SortOrder { ASCENDING, DESCENDING }

data class SortOption(
    val field: SortField = SortField.DATE_ADDED,
    val order: SortOrder = SortOrder.DESCENDING,
)

enum class RepeatMode { OFF, ONE, ALL }

data class MediaFolder(
    val path: String,
    val name: String,
    val itemCount: Int,
)

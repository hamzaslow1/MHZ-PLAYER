package com.mhzplayer.app.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.components.MediaCard
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzRed
import com.mhzplayer.app.ui.theme.MhzTextSecondary

@Composable
fun SearchScreen(
    state: SearchUiState,
    onQueryChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onClear: () -> Unit,
    onClearHistory: () -> Unit,
    onHistoryClick: (String) -> Unit,
    onPlayMedia: (MediaItem) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        Text("Search", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = state.query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
            placeholder = { Text("Bincika waƙa, bidiyo, mawaƙi…", color = MhzTextSecondary) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (state.query.isNotEmpty()) {
                    Icon(Icons.Filled.Clear, contentDescription = "Clear", modifier = Modifier.clickable { onClear() })
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = MhzCardElevated, focusedContainerColor = MhzCardElevated),
        )

        when {
            state.query.isBlank() && state.history.isNotEmpty() -> {
                Row(modifier = Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Tarihin Bincike", style = MaterialTheme.typography.titleMedium)
                    Text("Share All", color = MhzRed, modifier = Modifier.clickable { onClearHistory() })
                }
                LazyColumn(modifier = Modifier.padding(top = 8.dp)) {
                    items(state.history) { q ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onHistoryClick(q) }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.History, contentDescription = null, tint = MhzTextSecondary)
                            Text(q, modifier = Modifier.padding(start = 12.dp))
                        }
                    }
                }
            }
            state.query.isBlank() -> {
                EmptyState(title = "Fara Bincike", message = "Rubuta suna, mawaƙi, ko fayil don fara.")
            }
            state.results.isEmpty() -> {
                EmptyState(title = "Babu Sakamako", message = "Ba a sami wani abu da ya dace da \"${state.query}\" ba.")
            }
            else -> {
                LazyColumn(modifier = Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(state.results, key = { "${it.type}-${it.id}" }) { item ->
                        SearchResultRow(item) { onSubmit(); onPlayMedia(item) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchResultRow(item: MediaItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MhzCardElevated)
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(item.title, fontWeight = FontWeight.SemiBold)
            Text(
                listOfNotNull(item.artist, item.type.name.lowercase().replaceFirstChar { it.uppercase() }).joinToString(" • "),
                color = MhzTextSecondary,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

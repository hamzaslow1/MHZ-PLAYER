package com.mhzplayer.app.ui.recent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.data.repository.RecentlyPlayedRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class RecentlyPlayedUiState(val items: List<MediaItem> = emptyList())

class RecentlyPlayedViewModel(
    private val mediaRepository: MediaRepository,
    private val recentlyPlayedRepository: RecentlyPlayedRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(RecentlyPlayedUiState())
    val state: StateFlow<RecentlyPlayedUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(mediaRepository.audio, mediaRepository.video, recentlyPlayedRepository.observeRecent(50)) { audio, video, recent ->
                val byId = (audio + video).associateBy { it.id to it.type }
                recent.mapNotNull { r -> byId[r.mediaId to MediaType.valueOf(r.type)] }
            }.collect { _state.value = RecentlyPlayedUiState(it) }
        }
    }

    fun clearHistory() { viewModelScope.launch { recentlyPlayedRepository.clearAll() } }
}

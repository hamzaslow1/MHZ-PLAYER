package com.mhzplayer.app.data.repository

import com.mhzplayer.app.data.local.FavoriteDao
import com.mhzplayer.app.data.local.FavoriteEntity
import com.mhzplayer.app.data.model.MediaType
import kotlinx.coroutines.flow.Flow

/** Phase 8 — real Favorites system, persisted locally via Room. */
class FavoritesRepository(private val dao: FavoriteDao) {

    fun observeFavoriteIds(): Flow<List<FavoriteEntity>> = dao.observeAll()

    fun observeIsFavorite(mediaId: Long, type: MediaType): Flow<Boolean> =
        dao.observeIsFavorite(mediaId, type.name)

    fun observeCount(): Flow<Int> = dao.observeCount()

    suspend fun toggle(mediaId: Long, type: MediaType, currentlyFavorite: Boolean) {
        if (currentlyFavorite) {
            dao.remove(mediaId, type.name)
        } else {
            dao.add(FavoriteEntity(mediaId, type.name, System.currentTimeMillis()))
        }
    }
}

package com.mhzplayer.app.ui.player.audio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.mhzplayer.app.data.model.RepeatMode
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.components.formatDuration
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzRed
import com.mhzplayer.app.ui.theme.MhzTextSecondary
import com.mhzplayer.app.data.repository.LyricsResult

@Composable
fun AudioPlayerScreen(
    state: AudioPlayerUiState,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenQueue: () -> Unit,
    onSetSleepTimer: (Int?) -> Unit,
) {
    val playback = state.playback
    val item = playback.currentItem

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        // Artwork
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(24.dp))
                .background(MhzCardElevated),
            contentAlignment = Alignment.Center,
        ) {
            if (item?.albumArtUri != null) {
                AsyncImage(
                    model = item.albumArtUri,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Icon(Icons.Filled.MusicNote, contentDescription = null, tint = MhzTextSecondary, modifier = Modifier.size(64.dp))
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(item?.title ?: "—", style = MaterialTheme.typography.titleLarge, maxLines = 1)
                Text(item?.artist ?: "Unknown Artist", color = MhzTextSecondary)
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    if (state.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (state.isFavorite) MhzRed else MhzTextSecondary,
                )
            }
        }

        Slider(
            value = playback.positionMs.toFloat().coerceAtMost(playback.durationMs.toFloat().coerceAtLeast(1f)),
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..playback.durationMs.toFloat().coerceAtLeast(1f),
            colors = SliderDefaults.colors(thumbColor = MhzRed, activeTrackColor = MhzRed, inactiveTrackColor = MhzCardElevated),
            modifier = Modifier.padding(top = 12.dp),
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatDuration(playback.positionMs), color = MhzTextSecondary, style = MaterialTheme.typography.bodyMedium)
            Text(formatDuration(playback.durationMs), color = MhzTextSecondary, style = MaterialTheme.typography.bodyMedium)
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onToggleShuffle) {
                Icon(Icons.Filled.Shuffle, contentDescription = "Shuffle", tint = if (playback.shuffleEnabled) MhzRed else MhzTextSecondary)
            }
            IconButton(onClick = onPrevious) { Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(34.dp)) }
            IconButton(
                onClick = onTogglePlayPause,
                modifier = Modifier.size(66.dp).clip(RoundedCornerShape(50)).background(MhzRed),
            ) {
                Icon(
                    if (playback.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp),
                )
            }
            IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(34.dp)) }
            IconButton(onClick = onCycleRepeat) {
                Icon(
                    if (playback.repeatMode == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repeat",
                    tint = if (playback.repeatMode == RepeatMode.OFF) MhzTextSecondary else MhzRed,
                )
            }
        }

        Spacer(modifier = Modifier.size(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            SleepTimerControl(state.sleepTimerMinutes, onSetSleepTimer)
            IconButton(onClick = onOpenQueue) { Icon(Icons.Filled.QueueMusic, contentDescription = "Queue") }
        }

        // Kalmomi (Lyrics)
        Text("Kalmomi", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 20.dp))
        when (val lyrics = state.lyrics) {
            is LyricsResult.None -> EmptyState(title = "Babu Kalmomi", message = "")
            is LyricsResult.PlainText -> Text(lyrics.text, color = MhzTextSecondary, modifier = Modifier.padding(top = 8.dp))
            is LyricsResult.Synced -> {
                LazyColumn(modifier = Modifier.padding(top = 8.dp).weight(1f, fill = false)) {
                    items(lyrics.lines) { line ->
                        val active = playback.positionMs >= line.timeMs
                        Text(
                            line.text,
                            color = if (active) MhzRed else MhzTextSecondary,
                            modifier = Modifier.padding(vertical = 4.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SleepTimerControl(minutes: Int?, onSet: (Int?) -> Unit) {
    val options = listOf(15, 30, 45, 60, 90)
    var expanded by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(Icons.Filled.Bedtime, contentDescription = "Sleep Timer", tint = if (minutes != null) MhzRed else MhzTextSecondary)
        }
        androidx.compose.material3.DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { m ->
                androidx.compose.material3.DropdownMenuItem(text = { Text("$m minutes") }, onClick = { onSet(m); expanded = false })
            }
            androidx.compose.material3.DropdownMenuItem(text = { Text("Off") }, onClick = { onSet(null); expanded = false })
        }
    }
}

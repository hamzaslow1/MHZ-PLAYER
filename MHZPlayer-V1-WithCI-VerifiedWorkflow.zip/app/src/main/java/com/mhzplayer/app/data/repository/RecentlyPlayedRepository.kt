package com.mhzplayer.app.data.repository

import com.mhzplayer.app.data.local.RecentlyPlayedDao
import com.mhzplayer.app.data.local.RecentlyPlayedEntity
import com.mhzplayer.app.data.model.MediaType
import kotlinx.coroutines.flow.Flow

/** Powers the Home screen's "Recently Played" and part of "Recommended For You" (Phase 6/8). */
class RecentlyPlayedRepository(private val dao: RecentlyPlayedDao) {

    fun observeRecent(limit: Int = 20): Flow<List<RecentlyPlayedEntity>> = dao.observeRecent(limit)
    fun observeFrequent(limit: Int = 20): Flow<List<RecentlyPlayedEntity>> = dao.observeFrequent(limit)

    suspend fun recordPlay(mediaId: Long, type: MediaType) =
        dao.recordPlay(mediaId, type.name, System.currentTimeMillis())

    suspend fun clearAll() = dao.clearAll()
}

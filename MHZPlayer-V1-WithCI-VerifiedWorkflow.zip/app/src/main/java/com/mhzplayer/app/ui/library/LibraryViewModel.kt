package com.mhzplayer.app.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.local.PlaylistEntity
import com.mhzplayer.app.data.model.LibraryFilter
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.SortOption
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.data.repository.PlaylistRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class LibraryUiState(
    val filter: LibraryFilter = LibraryFilter.ALL,
    val sortOption: SortOption = SortOption(),
    val items: List<MediaItem> = emptyList(),
    val playlists: List<PlaylistEntity> = emptyList(),
    val folders: List<Pair<String, Int>> = emptyList(),
    val isScanning: Boolean = false,
)

/** A small private aggregate so we can chain two 4-arg `combine` calls instead of one 6-arg call
 *  (kotlinx.coroutines only ships typed `combine` overloads up to 5 flows). */
private data class LibraryFlowsPart1(
    val audio: List<MediaItem>,
    val video: List<MediaItem>,
    val playlists: List<PlaylistEntity>,
    val filter: LibraryFilter,
)

/** Phase 4 — real Library screen: Duka/Video/Audio/Playlist filters, sorting, refresh. */
class LibraryViewModel(
    private val mediaRepository: MediaRepository,
    private val playlistRepository: PlaylistRepository,
    initialFilter: LibraryFilter,
) : ViewModel() {

    private val _filter = MutableStateFlow(initialFilter)
    private val _sort = MutableStateFlow(SortOption())

    private val _state = MutableStateFlow(LibraryUiState(filter = initialFilter))
    val state: StateFlow<LibraryUiState> = _state.asStateFlow()

    init {
        val part1 = combine(
            mediaRepository.audio,
            mediaRepository.video,
            playlistRepository.observePlaylists(),
            _filter,
        ) { audio, video, playlists, filter -> LibraryFlowsPart1(audio, video, playlists, filter) }

        viewModelScope.launch {
            combine(part1, _sort, mediaRepository.isScanning) { p1, sort, scanning ->
                val base = when (p1.filter) {
                    LibraryFilter.ALL -> p1.audio + p1.video
                    LibraryFilter.AUDIO -> p1.audio
                    LibraryFilter.VIDEO -> p1.video
                    LibraryFilter.PLAYLIST -> emptyList()
                }
                LibraryUiState(
                    filter = p1.filter,
                    sortOption = sort,
                    items = mediaRepository.sorted(base, sort),
                    playlists = p1.playlists,
                    folders = if (p1.filter == LibraryFilter.VIDEO) mediaRepository.foldersFor(p1.video) else emptyList(),
                    isScanning = scanning,
                )
            }.collect { _state.value = it }
        }
    }

    fun setFilter(filter: LibraryFilter) { _filter.value = filter }
    fun setSort(option: SortOption) { _sort.value = option }
    fun refresh() { viewModelScope.launch { mediaRepository.refresh() } }
}

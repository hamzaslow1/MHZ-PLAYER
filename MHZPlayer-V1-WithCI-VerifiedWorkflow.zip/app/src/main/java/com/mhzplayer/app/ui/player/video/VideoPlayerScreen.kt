package com.mhzplayer.app.ui.player.video

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.components.formatDuration
import com.mhzplayer.app.ui.theme.MhzRed

/**
 * Phase 7/18/19 — video player screen. PlayerView renders the ExoPlayer surface; the
 * gesture-friendly custom overlay adds play/pause, seek, ±10s, playback speed, and a
 * Picture-in-Picture entry point (actual PiP mode switch is triggered by the hosting
 * Activity via [onEnterPip], since only an Activity can call enterPictureInPictureMode).
 */
@Composable
fun VideoPlayerScreen(
    state: VideoPlayerUiState,
    exoPlayer: ExoPlayer,
    onTogglePlayPause: () -> Unit,
    onSeekBy: (Long) -> Unit,
    onSeekTo: (Long) -> Unit,
    onSetSpeed: (Float) -> Unit,
    onChangeVolume: (Float) -> Unit,
    onToggleSubtitles: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onBrightness: (Float) -> Unit,
    onEnterPip: () -> Unit,
) {
    var livePositionMs by remember { mutableStateOf(state.positionMs) }
    var liveDurationMs by remember { mutableStateOf(state.durationMs) }
    LaunchedEffect(exoPlayer, state.isPlaying) {
        while (state.isPlaying) {
            livePositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            liveDurationMs = exoPlayer.duration.takeIf { it > 0 } ?: state.durationMs
            delay(500)
        }
    }
    livePositionMs = if (state.isPlaying) livePositionMs else state.positionMs
    liveDurationMs = liveDurationMs.coerceAtLeast(1L)

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (state.error != null) {
            EmptyState(title = "Kuskure", message = state.error, modifier = Modifier.align(Alignment.Center))
            return
        }

        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { player = exoPlayer; useController = false } },
            modifier = Modifier.fillMaxSize(),
        )

        // Custom gesture-friendly control overlay
        Column2 {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.End,
            ) {
                var speedMenu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { speedMenu = true }) {
                        Icon(Icons.Filled.Speed, contentDescription = "Playback Speed", tint = Color.White)
                    }
                    DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                            DropdownMenuItem(text = { Text("${speed}x") }, onClick = { onSetSpeed(speed); speedMenu = false })
                        }
                    }
                }
                IconButton(onClick = onToggleSubtitles) {
                    Icon(Icons.Filled.Subtitles, contentDescription = "Subtitles", tint = if (state.subtitlesEnabled) MhzRed else Color.White)
                }
                IconButton(onClick = { onChangeVolume(0.1f) }) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = "Increase volume", tint = Color.White)
                }
                IconButton(onClick = { onBrightness(0.1f) }) {
                    Icon(Icons.Filled.Brightness6, contentDescription = "Increase brightness", tint = Color.White)
                }
                IconButton(onClick = onToggleFullscreen) {
                    Icon(Icons.Filled.Fullscreen, contentDescription = "Fullscreen", tint = Color.White)
                }
                IconButton(onClick = onEnterPip) {
                    Icon(Icons.Filled.PictureInPicture, contentDescription = "Picture-in-Picture", tint = Color.White)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.Center,
            ) {
                Text("Volume ${((state.volume * 100).toInt())}%", color = Color.White, style = MaterialTheme.typography.labelMedium)
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { onSeekBy(-10_000L) }) {
                    Icon(Icons.Filled.Replay10, contentDescription = "Back 10s", tint = Color.White, modifier = Modifier.size(30.dp))
                }
                IconButton(
                    onClick = onTogglePlayPause,
                    modifier = Modifier.padding(horizontal = 24.dp),
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = Color.White,
                        modifier = Modifier.size(44.dp),
                    )
                }
                IconButton(onClick = { onSeekBy(10_000L) }) {
                    Icon(Icons.Filled.Forward10, contentDescription = "Forward 10s", tint = Color.White)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(formatDuration(livePositionMs), color = Color.White, style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = livePositionMs.toFloat(),
                    onValueChange = { onSeekTo(it.toLong()) },
                    valueRange = 0f..liveDurationMs.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = MhzRed, activeTrackColor = MhzRed, inactiveTrackColor = Color.White.copy(alpha = 0.3f)),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text(formatDuration(liveDurationMs), color = Color.White, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun Column2(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    androidx.compose.foundation.layout.Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
        content = content,
    )
}

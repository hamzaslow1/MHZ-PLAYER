package com.mhzplayer.app.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.data.model.LibraryFilter
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.model.SortField
import com.mhzplayer.app.data.model.SortOption
import com.mhzplayer.app.data.model.SortOrder
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.components.MediaCard
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzRed

@Composable
fun LibraryScreen(
    state: LibraryUiState,
    onFilterChange: (LibraryFilter) -> Unit,
    onRefresh: () -> Unit,
    onOpenPlaylists: () -> Unit,
    onPlayMedia: (MediaItem) -> Unit,
    onSortChange: (SortOption) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        var sortExpanded by remember { mutableStateOf(false) }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Library", style = MaterialTheme.typography.headlineMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box {
                    IconButton(onClick = { sortExpanded = true }) {
                        Icon(Icons.Filled.Sort, contentDescription = "Sort", tint = MhzRed)
                    }
                    DropdownMenu(expanded = sortExpanded, onDismissRequest = { sortExpanded = false }) {
                        listOf(
                            SortOption(SortField.DATE_ADDED, SortOrder.DESCENDING) to "Newest",
                            SortOption(SortField.NAME, SortOrder.ASCENDING) to "Name A–Z",
                            SortOption(SortField.NAME, SortOrder.DESCENDING) to "Name Z–A",
                            SortOption(SortField.DURATION, SortOrder.DESCENDING) to "Longest",
                            SortOption(SortField.SIZE, SortOrder.DESCENDING) to "Largest",
                        ).forEach { (option, label) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = { onSortChange(option); sortExpanded = false })
                        }
                    }
                }
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Refresh Library", tint = MhzRed)
                }
            }
        }

        Row(modifier = Modifier.padding(top = 12.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip("Duka", state.filter == LibraryFilter.ALL) { onFilterChange(LibraryFilter.ALL) }
            FilterChip("Video", state.filter == LibraryFilter.VIDEO) { onFilterChange(LibraryFilter.VIDEO) }
            FilterChip("Audio", state.filter == LibraryFilter.AUDIO) { onFilterChange(LibraryFilter.AUDIO) }
            FilterChip("Playlist", state.filter == LibraryFilter.PLAYLIST) { onFilterChange(LibraryFilter.PLAYLIST) }
        }

        if (state.filter == LibraryFilter.VIDEO && state.folders.isNotEmpty()) {
            Text("Folders", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                state.folders.take(4).forEach { (name, count) ->
                    Text(
                        "$name ($count)",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(MhzCardElevated)
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }

        when {
            state.isScanning && state.items.isEmpty() -> {
                Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    CircularProgressIndicator(color = MhzRed)
                    Text("Ana bincika media…", modifier = Modifier.padding(top = 12.dp))
                }
            }
            state.filter == LibraryFilter.PLAYLIST -> {
                if (state.playlists.isEmpty()) {
                    EmptyState(title = "Babu Playlist", message = "Create your first playlist.", actionLabel = "Buɗe Playlists", onAction = onOpenPlaylists)
                } else {
                    LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(bottom = 90.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(state.playlists) { playlist ->
                            PlaylistTile(name = playlist.name, onClick = onOpenPlaylists)
                        }
                    }
                }
            }
            state.items.isEmpty() -> {
                val isVideo = state.filter == LibraryFilter.VIDEO
                EmptyState(
                    title = if (isVideo) "Babu Bidiyo" else "Babu Waƙa",
                    message = if (isVideo) "Ba a sami bidiyo a cikin wayarka ba." else "Ba a sami waƙa a cikin wayarka ba.",
                )
            }
            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(bottom = 90.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(state.items, key = { "${it.type}-${it.id}" }) { item ->
                        MediaCard(item = item, onClick = { onPlayMedia(item) })
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) MhzRed else MhzCardElevated)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(label, color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PlaylistTile(name: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(MhzCardElevated)
            .clickable { onClick() }
            .padding(16.dp),
    ) {
        Text(name, style = MaterialTheme.typography.titleMedium)
    }
}

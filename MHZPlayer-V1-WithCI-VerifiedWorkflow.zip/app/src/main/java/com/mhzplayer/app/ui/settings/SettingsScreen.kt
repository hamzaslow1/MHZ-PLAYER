package com.mhzplayer.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzRed
import com.mhzplayer.app.ui.theme.MhzTextSecondary

@Composable
fun SettingsScreen(
    state: SettingsUiState,
    onAutoplayChange: (Boolean) -> Unit,
    onShuffleDefaultChange: (Boolean) -> Unit,
    onRememberPositionChange: (Boolean) -> Unit,
    onNotificationsChange: (Boolean) -> Unit,
    onRefreshLibrary: () -> Unit,
    onOpenAbout: () -> Unit,
    onExit: () -> Unit,
) {
    var showAbout by remember { mutableStateOf(false) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        item { Text("Settings", style = MaterialTheme.typography.headlineMedium) }

        item { SettingsSectionTitle("Playback") }
        item { SwitchRow("Autoplay", state.autoplay, onAutoplayChange) }
        item { SwitchRow("Shuffle by default", state.shuffleDefault, onShuffleDefaultChange) }

        item { SettingsSectionTitle("Video") }
        item { SwitchRow("Remember playback position", state.rememberVideoPosition, onRememberPositionChange) }

        item { SettingsSectionTitle("Library") }
        item { ActionRow("Scan / Refresh Library (${state.audioFileCount + state.videoFileCount} files)", onRefreshLibrary) }

        item { SettingsSectionTitle("Notifications") }
        item { SwitchRow("Player notification", state.notificationsEnabled, onNotificationsChange) }

        item { SettingsSectionTitle("Storage") }
        item { InfoRow("Audio files", "${state.audioFileCount}") }
        item { InfoRow("Video files", "${state.videoFileCount}") }

        item { SettingsSectionTitle("Appearance") }
        item { InfoRow("Theme", "Dark • MHZ Red") }

        item { SettingsSectionTitle("About") }
        item { ActionRow("MHZ PLAYER — Version 1.0.0", { showAbout = true; onOpenAbout() }, icon = Icons.Filled.Info) }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp, bottom = 60.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MhzCardElevated)
                    .clickable { onExit() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.ExitToApp, contentDescription = null, tint = MhzRed)
                Text("Fita", color = MhzRed, modifier = Modifier.padding(start = 12.dp))
            }
        }
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("MHZ PLAYER") },
            text = { Text("Version 1.0.0\n\nVideo + music player designed for local media playback.") },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } },
        )
    }
}

@Composable
private fun SettingsSectionTitle(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = MhzRed, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = MhzRed),
        )
    }
}

@Composable
private fun ActionRow(label: String, onClick: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Filled.ChevronRight) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label)
        Icon(icon, contentDescription = null, tint = MhzTextSecondary)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = MhzTextSecondary)
        Text(value)
    }
}

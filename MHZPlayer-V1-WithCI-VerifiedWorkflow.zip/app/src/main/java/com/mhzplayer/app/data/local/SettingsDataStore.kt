package com.mhzplayer.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "mhz_player_settings")

/**
 * Local, offline-first persistence for user settings (Playback, Audio, Video, Library,
 * Notifications, Appearance). Values survive app close/reopen as required by the spec.
 */
class SettingsDataStore(private val context: Context) {

    private object Keys {
        val AUTOPLAY = booleanPreferencesKey("autoplay")
        val SHUFFLE_ON_BY_DEFAULT = booleanPreferencesKey("shuffle_default")
        val REPEAT_MODE = stringPreferencesKey("repeat_mode")
        val PLAYBACK_SPEED = floatPreferencesKey("playback_speed")
        val REMEMBER_VIDEO_POSITION = booleanPreferencesKey("remember_video_position")
        val DEFAULT_ORIENTATION = stringPreferencesKey("default_orientation")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val SLEEP_TIMER_MINUTES = intPreferencesKey("sleep_timer_minutes")
        val LAST_SORT_FIELD = stringPreferencesKey("last_sort_field")
        val LAST_SORT_ORDER = stringPreferencesKey("last_sort_order")
    }

    val autoplay: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTOPLAY] ?: true }
    val shuffleDefault: Flow<Boolean> = context.dataStore.data.map { it[Keys.SHUFFLE_ON_BY_DEFAULT] ?: false }
    val repeatMode: Flow<String> = context.dataStore.data.map { it[Keys.REPEAT_MODE] ?: "OFF" }
    val playbackSpeed: Flow<Float> = context.dataStore.data.map { it[Keys.PLAYBACK_SPEED] ?: 1.0f }
    val rememberVideoPosition: Flow<Boolean> = context.dataStore.data.map { it[Keys.REMEMBER_VIDEO_POSITION] ?: true }
    val defaultOrientation: Flow<String> = context.dataStore.data.map { it[Keys.DEFAULT_ORIENTATION] ?: "AUTO" }
    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.NOTIFICATIONS_ENABLED] ?: true }
    val lastSortField: Flow<String> = context.dataStore.data.map { it[Keys.LAST_SORT_FIELD] ?: "DATE_ADDED" }
    val lastSortOrder: Flow<String> = context.dataStore.data.map { it[Keys.LAST_SORT_ORDER] ?: "DESCENDING" }

    suspend fun setAutoplay(value: Boolean) = context.dataStore.edit { it[Keys.AUTOPLAY] = value }
    suspend fun setShuffleDefault(value: Boolean) = context.dataStore.edit { it[Keys.SHUFFLE_ON_BY_DEFAULT] = value }
    suspend fun setRepeatMode(value: String) = context.dataStore.edit { it[Keys.REPEAT_MODE] = value }
    suspend fun setPlaybackSpeed(value: Float) = context.dataStore.edit { it[Keys.PLAYBACK_SPEED] = value }
    suspend fun setRememberVideoPosition(value: Boolean) = context.dataStore.edit { it[Keys.REMEMBER_VIDEO_POSITION] = value }
    suspend fun setDefaultOrientation(value: String) = context.dataStore.edit { it[Keys.DEFAULT_ORIENTATION] = value }
    suspend fun setNotificationsEnabled(value: Boolean) = context.dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = value }
    suspend fun setSortOption(field: String, order: String) = context.dataStore.edit {
        it[Keys.LAST_SORT_FIELD] = field
        it[Keys.LAST_SORT_ORDER] = order
    }
}

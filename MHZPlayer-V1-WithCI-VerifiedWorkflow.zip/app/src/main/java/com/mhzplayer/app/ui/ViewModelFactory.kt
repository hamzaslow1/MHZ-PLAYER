package com.mhzplayer.app.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.mhzplayer.app.ServiceLocator
import com.mhzplayer.app.data.model.LibraryFilter
import com.mhzplayer.app.ui.favorites.FavoritesViewModel
import com.mhzplayer.app.ui.audio.AudioLibraryViewModel
import com.mhzplayer.app.ui.home.HomeViewModel
import com.mhzplayer.app.ui.library.LibraryViewModel
import com.mhzplayer.app.ui.player.audio.AudioPlayerViewModel
import com.mhzplayer.app.ui.player.video.VideoPlayerViewModel
import com.mhzplayer.app.ui.playlist.PlaylistDetailViewModel
import com.mhzplayer.app.ui.playlist.PlaylistsViewModel
import com.mhzplayer.app.ui.search.SearchViewModel
import com.mhzplayer.app.ui.settings.SettingsViewModel
import com.mhzplayer.app.ui.recent.RecentlyPlayedViewModel

/**
 * Manual ViewModel factory driven by [ServiceLocator] — avoids requiring Hilt/Dagger setup
 * while still giving every screen its dependencies (repositories, PlayerController).
 */
class MhzViewModelFactory(
    private val context: Context,
    private val libraryFilter: LibraryFilter = LibraryFilter.ALL,
    private val playlistId: Long = 0L,
) : ViewModelProvider.Factory {

    private val locator get() = ServiceLocator.get(context)

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
        return when (modelClass) {
            HomeViewModel::class.java -> HomeViewModel(
                locator.mediaRepository, locator.favoritesRepository, locator.playlistRepository, locator.recentlyPlayedRepository,
            ) as T
            LibraryViewModel::class.java -> LibraryViewModel(locator.mediaRepository, locator.playlistRepository, libraryFilter) as T
            AudioLibraryViewModel::class.java -> AudioLibraryViewModel(locator.mediaRepository, locator.playerController) as T
            SearchViewModel::class.java -> SearchViewModel(locator.mediaRepository) as T
            AudioPlayerViewModel::class.java -> AudioPlayerViewModel(
                locator.playerController, locator.mediaRepository, locator.favoritesRepository, locator.recentlyPlayedRepository, locator.lyricsRepository,
            ) as T
            VideoPlayerViewModel::class.java -> VideoPlayerViewModel(
                context, locator.mediaRepository, locator.recentlyPlayedRepository, locator.settingsRepository,
            ) as T
            FavoritesViewModel::class.java -> FavoritesViewModel(locator.mediaRepository, locator.favoritesRepository) as T
            RecentlyPlayedViewModel::class.java -> RecentlyPlayedViewModel(locator.mediaRepository, locator.recentlyPlayedRepository) as T
            PlaylistsViewModel::class.java -> PlaylistsViewModel(locator.playlistRepository) as T
            PlaylistDetailViewModel::class.java -> PlaylistDetailViewModel(playlistId, locator.mediaRepository, locator.playlistRepository) as T
            SettingsViewModel::class.java -> SettingsViewModel(locator.settingsRepository, locator.mediaRepository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: $modelClass")
        }
    }
}

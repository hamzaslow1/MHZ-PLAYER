package com.mhzplayer.app.playback

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.model.RepeatMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlaybackUiState(
    val currentItem: MediaItem? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val queue: List<MediaItem> = emptyList(),
)

/**
 * App-side wrapper around a [MediaController] bound to [PlaybackService]. Every screen
 * (Home mini-player, full Audio Player, Video Player, Queue) drives playback through this
 * single controller so state (queue, shuffle, repeat, position) is always consistent —
 * this is Phase 6/7/12/14's "one playback engine, one source of truth" requirement.
 */
class PlayerController(private val context: Context) {

    private var controller: MediaController? = null
    private val queueItems = mutableListOf<MediaItem>()
    private var positionTickerJob: kotlinx.coroutines.Job? = null

    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    private var sleepTimerJob: kotlinx.coroutines.Job? = null

    fun connect(onReady: () -> Unit = {}) {
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        future.addListener({
            controller = future.get()
            controller?.addListener(playerListener)
            positionTickerJob?.cancel()
            positionTickerJob = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main.immediate).launch {
                while (isActive) {
                    syncFromController()
                    delay(500L)
                }
            }
            onReady()
        }, MoreExecutors.directExecutor())
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.value = _state.value.copy(isPlaying = isPlaying)
        }
        override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
            syncFromController(newPosition.positionMs)
        }
        override fun onMediaItemTransition(mediaItem: Media3Item?, reason: Int) {
            val index = controller?.currentMediaItemIndex ?: -1
            val current = queueItems.getOrNull(index)
            _state.value = _state.value.copy(
                currentItem = current,
                positionMs = controller?.currentPosition ?: 0L,
                durationMs = controller?.duration?.coerceAtLeast(0L) ?: current?.durationMs ?: 0L,
            )
        }
        override fun onPlaybackStateChanged(playbackState: Int) {
            syncFromController()
        }
    }

    fun playQueue(items: List<MediaItem>, startIndex: Int) {
        queueItems.clear()
        queueItems.addAll(items)
        val mediaItems = items.map { it.toMedia3Item() }
        controller?.apply {
            setMediaItems(mediaItems, startIndex, 0L)
            prepare()
            play()
        }
        val current = items.getOrNull(startIndex)
        _state.value = _state.value.copy(
            queue = items,
            currentItem = current,
            positionMs = 0L,
            durationMs = current?.durationMs ?: 0L,
        )
    }

    fun togglePlayPause() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun next() = controller?.seekToNextMediaItem()
    fun previous() = controller?.seekToPreviousMediaItem()
    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
        _state.value = _state.value.copy(positionMs = positionMs)
    }

    fun toggleShuffle() {
        val enabled = !_state.value.shuffleEnabled
        controller?.shuffleModeEnabled = enabled
        _state.value = _state.value.copy(shuffleEnabled = enabled)
    }

    fun cycleRepeatMode() {
        val next = when (_state.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        controller?.repeatMode = when (next) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
        }
        _state.value = _state.value.copy(repeatMode = next)
    }

    fun removeFromQueue(index: Int) {
        controller?.removeMediaItem(index)
        if (index in queueItems.indices) queueItems.removeAt(index)
        _state.value = _state.value.copy(queue = queueItems.toList())
    }

    fun moveInQueue(from: Int, to: Int) {
        controller?.moveMediaItem(from, to)
        if (from in queueItems.indices && to in queueItems.indices) {
            val item = queueItems.removeAt(from)
            queueItems.add(to, item)
        }
        _state.value = _state.value.copy(queue = queueItems.toList())
    }

    fun clearQueue() {
        controller?.clearMediaItems()
        queueItems.clear()
        _state.value = _state.value.copy(queue = emptyList(), currentItem = null)
    }

    /** Section 17 — Sleep Timer: stops playback after the given number of minutes. */
    fun startSleepTimer(minutes: Int, scope: CoroutineScope) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) return
        sleepTimerJob = scope.launch {
            delay(minutes * 60_000L)
            controller?.pause()
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
    }

    fun release() {
        positionTickerJob?.cancel()
        positionTickerJob = null
        controller?.removeListener(playerListener)
        controller?.release()
        controller = null
    }

    private fun syncFromController(positionOverride: Long? = null) {
        val c = controller ?: return
        val index = c.currentMediaItemIndex
        val current = queueItems.getOrNull(index)
        val duration = c.duration.takeIf { it >= 0L } ?: current?.durationMs ?: 0L
        _state.value = _state.value.copy(
            currentItem = current ?: _state.value.currentItem,
            isPlaying = c.isPlaying,
            positionMs = positionOverride ?: c.currentPosition.coerceAtLeast(0L),
            durationMs = duration.coerceAtLeast(0L),
        )
    }

    private fun MediaItem.toMedia3Item(): Media3Item {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(albumArtUri?.let { android.net.Uri.parse(it) })
            .build()
        return Media3Item.Builder()
            .setUri(uriString)
            .setMediaId(id.toString())
            .setMediaMetadata(metadata)
            .build()
    }
}

package com.mhzplayer.app.ui.recent

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.components.MediaCard

@Composable
fun RecentlyPlayedScreen(items: List<MediaItem>, onPlay: (MediaItem) -> Unit, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Recently Played", style = MaterialTheme.typography.headlineMedium)
            if (items.isNotEmpty()) TextButton(onClick = onClear) { Text("Clear", color = com.mhzplayer.app.ui.theme.MhzRed) }
        }
        if (items.isEmpty()) {
            EmptyState(title = "Babu Tarihi", message = "Media da ka kunna kwanan nan za su bayyana a nan.")
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(top = 16.dp)) {
                items(items, key = { "${it.type}-${it.id}" }) { item -> MediaCard(item = item, onClick = { onPlay(item) }) }
            }
        }
    }
}

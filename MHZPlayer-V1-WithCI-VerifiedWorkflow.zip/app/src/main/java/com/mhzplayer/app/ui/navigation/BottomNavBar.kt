package com.mhzplayer.app.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.ui.theme.MhzRed
import com.mhzplayer.app.ui.theme.MhzSurface
import com.mhzplayer.app.ui.theme.MhzTextSecondary

private fun iconFor(destination: Destination): ImageVector = when (destination) {
    Destination.Home -> Icons.Filled.Home
    Destination.Library -> Icons.Filled.LibraryMusic
    Destination.Search -> Icons.Filled.Search
    Destination.Settings -> Icons.Filled.Settings
    else -> Icons.Filled.Home
}

private fun labelFor(destination: Destination): String = when (destination) {
    Destination.Home -> "Home"
    Destination.Library -> "Library"
    Destination.Search -> "Search"
    Destination.Settings -> "Settings"
    else -> ""
}

/** Bottom navigation matching the prototype: gray inactive icons, red active icon + label + indicator. */
@Composable
fun MhzBottomNavBar(currentRoute: String?, onNavigate: (Destination) -> Unit) {
    NavigationBar(containerColor = MhzSurface, modifier = Modifier.height(64.dp)) {
        bottomNavDestinations.forEach { destination ->
            val selected = currentRoute == destination.route || currentRoute?.startsWith(destination.route.substringBefore("?")) == true
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(destination) },
                icon = { Icon(iconFor(destination), contentDescription = labelFor(destination)) },
                label = { Text(labelFor(destination)) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MhzRed,
                    selectedTextColor = MhzRed,
                    indicatorColor = MhzSurface,
                    unselectedIconColor = MhzTextSecondary,
                    unselectedTextColor = MhzTextSecondary,
                ),
            )
        }
    }
}

package com.mhzplayer.app.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.repository.MediaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SearchUiState(
    val query: String = "",
    val results: List<MediaItem> = emptyList(),
    val history: List<String> = emptyList(),
)

/** Phase 5 — real, as-you-type search across the actual scanned media library. */
class SearchViewModel(private val mediaRepository: MediaRepository) : ViewModel() {

    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    private val historyList = mutableListOf<String>()

    fun onQueryChange(query: String) {
        _state.value = _state.value.copy(query = query, results = mediaRepository.search(query))
    }

    fun commitToHistory() {
        val q = _state.value.query.trim()
        if (q.isNotEmpty() && !historyList.contains(q)) {
            historyList.add(0, q)
            if (historyList.size > 10) historyList.removeAt(historyList.lastIndex)
            _state.value = _state.value.copy(history = historyList.toList())
        }
    }

    fun clearQuery() {
        _state.value = _state.value.copy(query = "", results = emptyList())
    }

    fun clearHistory() {
        historyList.clear()
        _state.value = _state.value.copy(history = emptyList())
    }
}

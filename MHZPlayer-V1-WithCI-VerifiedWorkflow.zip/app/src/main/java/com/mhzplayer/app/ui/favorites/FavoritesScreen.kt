package com.mhzplayer.app.ui.favorites

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.components.MediaCard

@Composable
fun FavoritesScreen(state: FavoritesUiState, onPlay: (MediaItem) -> Unit, onClear: () -> Unit = {}) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        androidx.compose.foundation.layout.Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Favorites", style = MaterialTheme.typography.headlineMedium)
            if (state.items.isNotEmpty()) androidx.compose.material3.TextButton(onClick = onClear) { Text("Clear", color = com.mhzplayer.app.ui.theme.MhzRed) }
        }
        if (state.items.isEmpty()) {
            EmptyState(title = "Babu Favorites", message = "Ka fara ƙara media zuwa Favorites.")
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.padding(top = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                items(state.items, key = { "${it.type}-${it.id}" }) { item ->
                    MediaCard(item = item, onClick = { onPlay(item) })
                }
            }
        }
    }
}

package com.mhzplayer.app.ui.player.audio

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.model.RepeatMode
import com.mhzplayer.app.data.repository.FavoritesRepository
import com.mhzplayer.app.data.repository.LyricsRepository
import com.mhzplayer.app.data.repository.LyricsResult
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.data.repository.RecentlyPlayedRepository
import com.mhzplayer.app.playback.PlaybackUiState
import com.mhzplayer.app.playback.PlayerController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged

import kotlinx.coroutines.launch

data class AudioPlayerUiState(
    val playback: PlaybackUiState = PlaybackUiState(),
    val isFavorite: Boolean = false,
    val lyrics: LyricsResult = LyricsResult.None,
    val sleepTimerMinutes: Int? = null,
)

/** Phase 6/9 — full audio player: playback controls, favorite, queue, lyrics, sleep timer. */
class AudioPlayerViewModel(
    private val playerController: PlayerController,
    private val mediaRepository: MediaRepository,
    private val favoritesRepository: FavoritesRepository,
    private val recentlyPlayedRepository: RecentlyPlayedRepository,
    private val lyricsRepository: LyricsRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(AudioPlayerUiState())
    val state: StateFlow<AudioPlayerUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            playerController.state.collect { playback ->
                _state.value = _state.value.copy(playback = playback)
            }
        }
        viewModelScope.launch {
            playerController.state
                .distinctUntilChanged { old, new -> old.currentItem?.id == new.currentItem?.id && old.currentItem?.type == new.currentItem?.type }
                .collect { playback ->
                    val item = playback.currentItem
                    if (item == null) {
                        _state.value = _state.value.copy(isFavorite = false, lyrics = LyricsResult.None)
                    } else {
                        observeFavorite(item)
                        loadLyrics(item)
                    }
                }
        }
    }

    fun playFromLibrary(mediaId: Long) {
        val allAudio = mediaRepository.audio.value
        val index = allAudio.indexOfFirst { it.id == mediaId }
        if (index == -1) return
        playerController.playQueue(allAudio, index)
        viewModelScope.launch { recentlyPlayedRepository.recordPlay(mediaId, MediaType.AUDIO) }
    }

    private fun loadLyrics(item: MediaItem) {
        viewModelScope.launch {
            val lyrics = lyricsRepository.loadFor(item.filePath)
            _state.value = _state.value.copy(lyrics = lyrics)
        }
    }

    private fun observeFavorite(item: MediaItem) {
        viewModelScope.launch {
            favoritesRepository.observeIsFavorite(item.id, item.type).collect { fav ->
                _state.value = _state.value.copy(isFavorite = fav)
            }
        }
    }

    fun togglePlayPause() = playerController.togglePlayPause()
    fun next() = playerController.next()
    fun previous() = playerController.previous()
    fun seekTo(ms: Long) = playerController.seekTo(ms)
    fun toggleShuffle() = playerController.toggleShuffle()
    fun cycleRepeat() = playerController.cycleRepeatMode()

    fun toggleFavorite() {
        val item = _state.value.playback.currentItem ?: return
        viewModelScope.launch {
            favoritesRepository.toggle(item.id, item.type, _state.value.isFavorite)
        }
    }

    fun playQueueIndex(index: Int) {
        val queue = _state.value.playback.queue
        if (index in queue.indices) playerController.playQueue(queue, index)
    }

    fun removeFromQueue(index: Int) = playerController.removeFromQueue(index)
    fun clearQueue() = playerController.clearQueue()

    fun setSleepTimer(minutes: Int?) {
        _state.value = _state.value.copy(sleepTimerMinutes = minutes)
        if (minutes == null) {
            playerController.cancelSleepTimer()
        } else {
            playerController.startSleepTimer(minutes, viewModelScope)
        }
    }
}

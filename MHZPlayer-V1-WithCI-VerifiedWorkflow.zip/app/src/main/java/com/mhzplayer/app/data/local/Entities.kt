package com.mhzplayer.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A media item the user marked as favorite. Stores mediaId (MediaStore id) + type so we
 *  can re-resolve the real file from MediaStore at read time — we never cache the file itself. */
@Entity(tableName = "favorites", primaryKeys = ["mediaId", "type"])
data class FavoriteEntity(
    val mediaId: Long,
    val type: String, // "AUDIO" | "VIDEO"
    val addedAtMillis: Long,
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val playlistId: Long = 0,
    val name: String,
    val createdAtMillis: Long,
)

@Entity(tableName = "playlist_items", primaryKeys = ["playlistId", "mediaId", "type"])
data class PlaylistItemEntity(
    val playlistId: Long,
    val mediaId: Long,
    val type: String,
    val position: Int,
)

@Entity(tableName = "recently_played", primaryKeys = ["mediaId", "type"])
data class RecentlyPlayedEntity(
    val mediaId: Long,
    val type: String,
    val playedAtMillis: Long,
    val playCount: Int = 1,
)

@Entity(tableName = "queue_items", primaryKeys = ["position"])
data class QueueItemEntity(
    val position: Int,
    val mediaId: Long,
    val type: String,
)

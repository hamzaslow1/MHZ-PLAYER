package com.mhzplayer.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.repository.FavoritesRepository
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.data.repository.PlaylistRepository
import com.mhzplayer.app.data.repository.RecentlyPlayedRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class HomeUiState(
    val videoCount: Int = 0,
    val audioCount: Int = 0,
    val favoritesCount: Int = 0,
    val playlistsCount: Int = 0,
    val recentlyPlayed: List<MediaItem> = emptyList(),
    val recommended: List<MediaItem> = emptyList(),
    val isScanning: Boolean = false,
)

private data class HomeFlowsPart1(
    val audio: List<MediaItem>,
    val video: List<MediaItem>,
    val favCount: Int,
    val playlistCount: Int,
)

/**
 * Drives the Home screen (Section 6-8). Quick Access counts, Recently Played, and
 * Recommended For You are all computed from real repositories — never hard-coded numbers.
 */
class HomeViewModel(
    private val mediaRepository: MediaRepository,
    private val favoritesRepository: FavoritesRepository,
    private val playlistRepository: PlaylistRepository,
    private val recentlyPlayedRepository: RecentlyPlayedRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch { mediaRepository.refresh() }

        val part1 = combine(
            mediaRepository.audio,
            mediaRepository.video,
            favoritesRepository.observeCount(),
            playlistRepository.observeCount(),
        ) { audio, video, favCount, playlistCount -> HomeFlowsPart1(audio, video, favCount, playlistCount) }

        viewModelScope.launch {
            combine(part1, recentlyPlayedRepository.observeRecent(10), mediaRepository.isScanning) { p1, recent, scanning ->
                val byId = (p1.audio + p1.video).associateBy { it.id to it.type }
                val recentItems = recent.mapNotNull { byId[it.mediaId to MediaType.valueOf(it.type)] }

                // Recommended For You: built from recently played history first, falling back
                // to recently added media when there's no play history yet — never fabricated.
                val recommended = if (recentItems.isNotEmpty()) {
                    recentItems.take(6)
                } else {
                    (p1.audio + p1.video).sortedByDescending { it.dateAddedSeconds }.take(6)
                }

                HomeUiState(
                    videoCount = p1.video.size,
                    audioCount = p1.audio.size,
                    favoritesCount = p1.favCount,
                    playlistsCount = p1.playlistCount,
                    recentlyPlayed = recentItems,
                    recommended = recommended,
                    isScanning = scanning,
                )
            }.collect { _state.value = it }
        }
    }

    fun refreshLibrary() {
        viewModelScope.launch { mediaRepository.refresh() }
    }
}

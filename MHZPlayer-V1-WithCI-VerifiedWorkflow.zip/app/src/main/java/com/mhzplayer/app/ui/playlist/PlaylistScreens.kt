package com.mhzplayer.app.ui.playlist

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.mhzplayer.app.data.local.PlaylistEntity
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzRed

@Composable
fun PlaylistsScreen(
    state: PlaylistsUiState,
    onCreate: (String) -> Unit,
    onRename: (Long, String) -> Unit,
    onDelete: (Long) -> Unit,
    onOpen: (Long) -> Unit,
) {
    var showCreate by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<PlaylistEntity?>(null) }

    Scaffold(
        floatingActionButton = { FloatingActionButton(onClick = { showCreate = true }, containerColor = MhzRed) { Icon(Icons.Filled.Add, "New Playlist") } },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 16.dp)) {
            Text("Playlists", style = MaterialTheme.typography.headlineMedium)
            if (state.playlists.isEmpty()) {
                EmptyState(title = "Babu Playlist", message = "Create your first playlist.", actionLabel = "Ƙirƙiri Playlist", onAction = { showCreate = true })
            } else {
                LazyColumn(Modifier.padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.playlists, key = { it.playlistId }) { playlist ->
                        PlaylistRow(playlist, onOpen = { onOpen(playlist.playlistId) }, onRename = { renameTarget = playlist }, onDelete = { onDelete(playlist.playlistId) })
                    }
                }
            }
        }
    }
    if (showCreate) PlaylistNameDialog("Sabon Playlist", "Ƙirƙiri", onDismiss = { showCreate = false }) { onCreate(it); showCreate = false }
    renameTarget?.let { target -> PlaylistNameDialog("Sake suna", "Ajiye", target.name, onDismiss = { renameTarget = null }) { onRename(target.playlistId, it); renameTarget = null } }
}

@Composable
private fun PlaylistNameDialog(title: String, confirm: String, initial: String = "", onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Sunan playlist") }) }, confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onConfirm(name.trim()) }) { Text(confirm, color = MhzRed) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Soke") } })
}

@Composable
private fun PlaylistRow(playlist: PlaylistEntity, onOpen: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MhzCardElevated).clickable { onOpen() }.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.PlaylistPlay, null, tint = MhzRed); Text(playlist.name, Modifier.padding(start = 12.dp)) }
        IconButton(onClick = onRename) { Icon(Icons.Filled.Edit, "Rename") }
        IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete") }
    }
}

@Composable
fun PlaylistDetailScreen(
    state: PlaylistDetailUiState,
    onPlay: (MediaItem) -> Unit,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    onAdd: (MediaItem) -> Unit,
    onRemove: (MediaItem) -> Unit,
) {
    var showAdd by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(state.name.ifEmpty { "Playlist" }, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = { showAdd = true }) { Icon(Icons.Filled.Add, "Add media") }
        }
        if (state.items.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPlayAll, colors = ButtonDefaults.buttonColors(containerColor = MhzRed)) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Play All") }
                OutlinedButton(onClick = onShuffle) { Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Shuffle") }
            }
        }
        if (state.items.isEmpty()) EmptyState(title = "Playlist ba komai", message = "Add videos ko songs zuwa playlist.", actionLabel = "Ƙara Media", onAction = { showAdd = true })
        else LazyColumn(Modifier.padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(state.items, key = { "${it.type}-${it.id}" }) { item ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MhzCardElevated).clickable { onPlay(item) }.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(item.title); item.artist?.let { Text(it, style = MaterialTheme.typography.bodySmall) } }
                    IconButton(onClick = { onRemove(item) }) { Icon(Icons.Filled.Delete, "Remove") }
                }
            }
        }
    }
    if (showAdd) {
        AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Ƙara zuwa playlist") }, text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                if (state.availableMedia.isEmpty()) item { Text("Babu sauran media da za a ƙara.") }
                else items(state.availableMedia, key = { "${it.type}-${it.id}" }) { item ->
                    Row(Modifier.fillMaxWidth().clickable { onAdd(item) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (item.type.name == "AUDIO") Icons.Filled.PlaylistPlay else Icons.Filled.PlayArrow, null, tint = MhzRed)
                        Column(Modifier.padding(start = 10.dp)) { Text(item.title); item.artist?.let { Text(it, style = MaterialTheme.typography.bodySmall) } }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { showAdd = false }) { Text("An gama") } })
    }
}

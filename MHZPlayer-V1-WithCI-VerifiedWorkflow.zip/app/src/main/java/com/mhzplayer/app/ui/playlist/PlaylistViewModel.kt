package com.mhzplayer.app.ui.playlist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.local.PlaylistEntity
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.data.repository.PlaylistRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PlaylistsUiState(val playlists: List<PlaylistEntity> = emptyList())

class PlaylistsViewModel(private val playlistRepository: PlaylistRepository) : ViewModel() {
    private val _state = MutableStateFlow(PlaylistsUiState())
    val state: StateFlow<PlaylistsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            playlistRepository.observePlaylists().collect { _state.value = PlaylistsUiState(it) }
        }
    }

    fun create(name: String) { if (name.isNotBlank()) viewModelScope.launch { playlistRepository.createPlaylist(name.trim()) } }
    fun rename(playlistId: Long, newName: String) { if (newName.isNotBlank()) viewModelScope.launch { playlistRepository.rename(playlistId, newName.trim()) } }
    fun delete(playlistId: Long) { viewModelScope.launch { playlistRepository.delete(playlistId) } }
}

data class PlaylistDetailUiState(
    val name: String = "",
    val items: List<MediaItem> = emptyList(),
    val availableMedia: List<MediaItem> = emptyList(),
)

class PlaylistDetailViewModel(
    private val playlistId: Long,
    private val mediaRepository: MediaRepository,
    private val playlistRepository: PlaylistRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(PlaylistDetailUiState())
    val state: StateFlow<PlaylistDetailUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            kotlinx.coroutines.flow.combine(
                playlistRepository.observeItems(playlistId),
                mediaRepository.audio,
                mediaRepository.video,
            ) { entries, audio, video ->
                val all = audio + video
                val byId = all.associateBy { it.id to it.type }
                val items = entries.sortedBy { it.position }.mapNotNull { byId[it.mediaId to MediaType.valueOf(it.type)] }
                val existing = items.map { it.id to it.type }.toSet()
                PlaylistDetailUiState(
                    name = _state.value.name,
                    items = items,
                    availableMedia = all.filterNot { (it.id to it.type) in existing }.sortedBy { it.title.lowercase() },
                )
            }.collect { next -> _state.value = next }
        }
        viewModelScope.launch {
            playlistRepository.observePlaylists().collect { playlists ->
                _state.value = _state.value.copy(name = playlists.find { it.playlistId == playlistId }?.name ?: "")
            }
        }
    }

    fun addItem(item: MediaItem) { viewModelScope.launch { playlistRepository.addItem(playlistId, item.id, item.type) } }
    fun removeItem(item: MediaItem) { viewModelScope.launch { playlistRepository.removeItem(playlistId, item.id, item.type) } }

    fun moveItem(from: Int, to: Int) {
        if (from == to || from !in _state.value.items.indices || to !in _state.value.items.indices) return
        val reordered = _state.value.items.toMutableList().apply { add(to, removeAt(from)) }
        _state.value = _state.value.copy(items = reordered)
        viewModelScope.launch {
            // Persist the visual order by writing positions in the current order.
            reordered.forEachIndexed { index, item ->
                playlistRepository.addItem(playlistId, item.id, item.type, index)
            }
        }
    }
}

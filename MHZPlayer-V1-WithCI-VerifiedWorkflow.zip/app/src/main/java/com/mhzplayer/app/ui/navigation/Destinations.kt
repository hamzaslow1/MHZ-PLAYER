package com.mhzplayer.app.ui.navigation

sealed class Destination(val route: String) {
    object Splash : Destination("splash")
    object Permission : Destination("permission")
    object Home : Destination("home")
    object AudioLibrary : Destination("audio-library")
    object Library : Destination("library?filter={filter}") {
        fun withFilter(filter: String) = "library?filter=$filter"
    }
    object Search : Destination("search")
    object Settings : Destination("settings")
    object Favorites : Destination("favorites")
    object RecentlyPlayed : Destination("recently-played")
    object Playlists : Destination("playlists")
    object PlaylistDetail : Destination("playlist/{playlistId}") {
        fun of(playlistId: Long) = "playlist/$playlistId"
    }
    object AudioPlayer : Destination("player/audio/{mediaId}") {
        fun of(mediaId: Long) = "player/audio/$mediaId"
    }
    object VideoPlayer : Destination("player/video/{mediaId}") {
        fun of(mediaId: Long) = "player/video/$mediaId"
    }
    object Queue : Destination("queue")
}

/** The four bottom navigation destinations, in the fixed order required by the spec. */
val bottomNavDestinations = listOf(Destination.Home, Destination.Library, Destination.Search, Destination.Settings)

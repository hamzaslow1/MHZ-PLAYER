package com.mhzplayer.app.ui.audio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.SortField
import com.mhzplayer.app.data.model.SortOption
import com.mhzplayer.app.data.model.SortOrder
import com.mhzplayer.app.ui.components.EmptyState
import com.mhzplayer.app.ui.components.formatDuration
import com.mhzplayer.app.ui.theme.MhzCardElevated
import com.mhzplayer.app.ui.theme.MhzRed
import com.mhzplayer.app.ui.theme.MhzTextSecondary

enum class AudioTab(val label: String) { SONGS("Songs"), ALBUMS("Albums"), ARTISTS("Artists") }
data class AudioGroup(val name: String, val items: List<MediaItem>)
data class AudioLibraryUiState(val tab: AudioTab = AudioTab.SONGS, val items: List<MediaItem> = emptyList(), val albums: List<AudioGroup> = emptyList(), val artists: List<AudioGroup> = emptyList(), val sort: SortOption = SortOption())

@Composable
fun AudioLibraryScreen(state: AudioLibraryUiState, onTabChange: (AudioTab) -> Unit, onRefresh: () -> Unit, onSort: (SortOption) -> Unit, onPlay: (MediaItem) -> Unit, onShuffle: () -> Unit) {
    var sortOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("Music", style = MaterialTheme.typography.headlineMedium); Text("Waƙoƙin da ke wayarka", color = MhzTextSecondary) }
            Row {
                IconButton(onClick = onShuffle) { Icon(Icons.Filled.Shuffle, "Shuffle", tint = MhzRed) }
                Box { IconButton(onClick = { sortOpen = true }) { Icon(Icons.Filled.Sort, "Sort") }; DropdownMenu(sortOpen, { sortOpen = false }) {
                    listOf(SortOption(SortField.NAME, SortOrder.ASCENDING) to "Name A–Z", SortOption(SortField.ARTIST, SortOrder.ASCENDING) to "Artist", SortOption(SortField.ALBUM, SortOrder.ASCENDING) to "Album", SortOption(SortField.DATE_ADDED, SortOrder.DESCENDING) to "Newest", SortOption(SortField.DURATION, SortOrder.DESCENDING) to "Longest").forEach { (o, label) -> DropdownMenuItem({ Text(label) }, { onSort(o); sortOpen = false }) }
                } }
            }
        }
        Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { AudioTab.values().forEach { tab -> Text(tab.label, color = if (state.tab == tab) Color.White else MhzTextSecondary, modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(if (state.tab == tab) MhzRed else MhzCardElevated).clickable { onTabChange(tab) }.padding(horizontal = 16.dp, vertical = 9.dp)) } }
        if (state.items.isEmpty()) EmptyState("Babu Waƙa", "Ba a sami audio a cikin wayarka ba.") else when (state.tab) {
            AudioTab.SONGS -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 90.dp)) { items(state.items, key = { it.id }) { SongRow(it, onPlay) } }
            AudioTab.ALBUMS -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 90.dp)) { items(state.albums, key = { it.name }) { AlbumRow(it, onPlay) } }
            AudioTab.ARTISTS -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 90.dp)) { items(state.artists, key = { it.name }) { ArtistRow(it, onPlay) } }
        }
    }
}
@Composable private fun SongRow(item: MediaItem, onPlay: (MediaItem) -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MhzCardElevated).clickable { onPlay(item) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Artwork(item, 58.dp); Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(item.title, maxLines = 1); Text(item.artist ?: "Unknown Artist", color = MhzTextSecondary, maxLines = 1) }; Text(formatDuration(item.durationMs), color = MhzTextSecondary); Icon(Icons.Filled.PlayArrow, "Play", tint = MhzRed, modifier = Modifier.padding(start = 8.dp)) } }
@Composable private fun AlbumRow(group: AudioGroup, onPlay: (MediaItem) -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MhzCardElevated).clickable { group.items.firstOrNull()?.let(onPlay) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Artwork(group.items.firstOrNull(), 58.dp); Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(group.name); Text("${group.items.size} songs • ${group.items.firstOrNull()?.artist ?: "Unknown Artist"}", color = MhzTextSecondary) }; Icon(Icons.Filled.Album, "Album", tint = MhzRed) } }
@Composable private fun ArtistRow(group: AudioGroup, onPlay: (MediaItem) -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MhzCardElevated).clickable { group.items.firstOrNull()?.let(onPlay) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.MusicNote, null, tint = MhzRed, modifier = Modifier.size(40.dp)); Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(group.name); Text("${group.items.size} songs", color = MhzTextSecondary) }; Icon(Icons.Filled.PlayArrow, "Play", tint = MhzRed) } }
@Composable private fun Artwork(item: MediaItem?, size: androidx.compose.ui.unit.Dp) { Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(MhzRed.copy(alpha = .18f)), contentAlignment = Alignment.Center) { if (item?.albumArtUri != null) AsyncImage(item.albumArtUri, item.title, Modifier.fillMaxSize()) else Icon(Icons.Filled.MusicNote, null, tint = MhzRed) } }

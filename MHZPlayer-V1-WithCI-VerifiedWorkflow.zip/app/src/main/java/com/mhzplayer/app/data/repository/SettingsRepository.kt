package com.mhzplayer.app.data.repository

import com.mhzplayer.app.data.local.SettingsDataStore
import com.mhzplayer.app.data.model.RepeatMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Thin, typed wrapper over [SettingsDataStore] for the Settings screen and player. */
class SettingsRepository(private val store: SettingsDataStore) {

    val autoplay: Flow<Boolean> = store.autoplay
    val shuffleDefault: Flow<Boolean> = store.shuffleDefault
    val repeatMode: Flow<RepeatMode> = store.repeatMode.map { runCatching { RepeatMode.valueOf(it) }.getOrDefault(RepeatMode.OFF) }
    val playbackSpeed: Flow<Float> = store.playbackSpeed
    val rememberVideoPosition: Flow<Boolean> = store.rememberVideoPosition
    val defaultOrientation: Flow<String> = store.defaultOrientation
    val notificationsEnabled: Flow<Boolean> = store.notificationsEnabled

    suspend fun setAutoplay(v: Boolean) = store.setAutoplay(v)
    suspend fun setShuffleDefault(v: Boolean) = store.setShuffleDefault(v)
    suspend fun setRepeatMode(v: RepeatMode) = store.setRepeatMode(v.name)
    suspend fun setPlaybackSpeed(v: Float) = store.setPlaybackSpeed(v)
    suspend fun setRememberVideoPosition(v: Boolean) = store.setRememberVideoPosition(v)
    suspend fun setDefaultOrientation(v: String) = store.setDefaultOrientation(v)
    suspend fun setNotificationsEnabled(v: Boolean) = store.setNotificationsEnabled(v)
}

package com.mhzplayer.app.ui.audio

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.model.SortOption
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.playback.PlayerController
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AudioLibraryViewModel(private val mediaRepository: MediaRepository, private val playerController: PlayerController) : ViewModel() {
    private val tab = MutableStateFlow(AudioTab.SONGS)
    private val sort = MutableStateFlow(SortOption())
    val state: StateFlow<AudioLibraryUiState> = combine(mediaRepository.audio, tab, sort) { audio, t, s ->
        val sorted = mediaRepository.sorted(audio, s)
        AudioLibraryUiState(t, sorted, group(sorted) { it.album ?: "Unknown Album" }, group(sorted) { it.artist ?: "Unknown Artist" }, s)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AudioLibraryUiState())
    init { viewModelScope.launch { if (mediaRepository.audio.value.isEmpty()) mediaRepository.refresh() } }
    fun setTab(t: AudioTab) { tab.value = t }
    fun setSort(s: SortOption) { sort.value = s }
    fun refresh() { viewModelScope.launch { mediaRepository.refresh() } }
    fun shuffle() { val a = mediaRepository.audio.value.shuffled(); if (a.isNotEmpty()) playerController.playQueue(a, 0) }
    private fun group(items: List<MediaItem>, key: (MediaItem) -> String) = items.groupBy(key).map { AudioGroup(it.key, it.value) }.sortedBy { it.name.lowercase() }
}

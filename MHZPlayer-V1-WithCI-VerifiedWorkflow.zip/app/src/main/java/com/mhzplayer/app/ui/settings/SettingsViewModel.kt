package com.mhzplayer.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.model.RepeatMode
import com.mhzplayer.app.data.repository.MediaRepository
import com.mhzplayer.app.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class SettingsUiState(
    val autoplay: Boolean = true,
    val shuffleDefault: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val playbackSpeed: Float = 1.0f,
    val rememberVideoPosition: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val audioFileCount: Int = 0,
    val videoFileCount: Int = 0,
)

/** Section 26 — Settings: Playback/Audio/Video/Library/Notifications/Storage/Appearance/About. */
class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val mediaRepository: MediaRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsUiState())
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                settingsRepository.autoplay,
                settingsRepository.shuffleDefault,
                settingsRepository.repeatMode,
                settingsRepository.playbackSpeed,
            ) { autoplay, shuffle, repeat, speed -> Quad(autoplay, shuffle, repeat, speed) }
                .collect { q ->
                    _state.value = _state.value.copy(
                        autoplay = q.a, shuffleDefault = q.b, repeatMode = q.c, playbackSpeed = q.d,
                    )
                }
        }
        viewModelScope.launch {
            combine(
                settingsRepository.rememberVideoPosition,
                settingsRepository.notificationsEnabled,
                mediaRepository.audio,
                mediaRepository.video,
            ) { remember, notif, audio, video ->
                _state.value.copy(
                    rememberVideoPosition = remember,
                    notificationsEnabled = notif,
                    audioFileCount = audio.size,
                    videoFileCount = video.size,
                )
            }.collect { _state.value = it }
        }
    }

    private data class Quad(val a: Boolean, val b: Boolean, val c: RepeatMode, val d: Float)

    fun setAutoplay(v: Boolean) = viewModelScope.launch { settingsRepository.setAutoplay(v) }
    fun setShuffleDefault(v: Boolean) = viewModelScope.launch { settingsRepository.setShuffleDefault(v) }
    fun setRepeatMode(v: RepeatMode) = viewModelScope.launch { settingsRepository.setRepeatMode(v) }
    fun setPlaybackSpeed(v: Float) = viewModelScope.launch { settingsRepository.setPlaybackSpeed(v) }
    fun setRememberVideoPosition(v: Boolean) = viewModelScope.launch { settingsRepository.setRememberVideoPosition(v) }
    fun setNotificationsEnabled(v: Boolean) = viewModelScope.launch { settingsRepository.setNotificationsEnabled(v) }
    fun refreshLibrary() = viewModelScope.launch { mediaRepository.refresh() }
}

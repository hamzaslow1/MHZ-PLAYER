package com.mhzplayer.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val MhzDarkColorScheme = darkColorScheme(
    primary = MhzRed,
    onPrimary = MhzTextPrimary,
    secondary = MhzAccentAudio,
    background = MhzBackground,
    onBackground = MhzTextPrimary,
    surface = MhzSurface,
    onSurface = MhzTextPrimary,
    surfaceVariant = MhzSurfaceVariant,
    onSurfaceVariant = MhzTextSecondary,
    error = MhzRed,
)

@Composable
fun MHZPlayerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MhzDarkColorScheme,
        typography = MhzTypography,
        content = content
    )
}

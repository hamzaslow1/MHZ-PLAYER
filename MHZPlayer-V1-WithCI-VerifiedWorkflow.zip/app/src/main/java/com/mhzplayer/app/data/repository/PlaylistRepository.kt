package com.mhzplayer.app.data.repository

import com.mhzplayer.app.data.local.PlaylistDao
import com.mhzplayer.app.data.local.PlaylistEntity
import com.mhzplayer.app.data.local.PlaylistItemEntity
import com.mhzplayer.app.data.model.MediaType
import kotlinx.coroutines.flow.Flow

/** Phase 8 — full local playlist system: create, rename, delete, add/remove/reorder items. */
class PlaylistRepository(private val dao: PlaylistDao) {

    fun observePlaylists(): Flow<List<PlaylistEntity>> = dao.observeAll()
    fun observeCount(): Flow<Int> = dao.observeCount()
    fun observeItems(playlistId: Long): Flow<List<PlaylistItemEntity>> = dao.observeItems(playlistId)
    fun observeItemCount(playlistId: Long): Flow<Int> = dao.observeItemCount(playlistId)

    suspend fun createPlaylist(name: String): Long =
        dao.createPlaylist(PlaylistEntity(name = name, createdAtMillis = System.currentTimeMillis()))

    suspend fun rename(playlistId: Long, newName: String) = dao.rename(playlistId, newName)

    suspend fun delete(playlistId: Long) {
        dao.clearItems(playlistId)
        dao.delete(playlistId)
    }

    suspend fun addItem(playlistId: Long, mediaId: Long, type: MediaType, position: Int? = null) {
        val finalPosition = position ?: (dao.maxPosition(playlistId) + 1)
        dao.addItem(PlaylistItemEntity(playlistId, mediaId, type.name, finalPosition))
    }

    suspend fun removeItem(playlistId: Long, mediaId: Long, type: MediaType) {
        dao.removeItem(playlistId, mediaId, type.name)
        normalizePositions(playlistId)
    }

    suspend fun reorder(playlistId: Long, orderedItems: List<PlaylistItemEntity>) {
        orderedItems.forEachIndexed { index, item ->
            dao.updatePosition(playlistId, item.mediaId, item.type, index)
        }
    }

    private suspend fun normalizePositions(playlistId: Long) {
        dao.observeItems(playlistId)
        // Reordering is best-effort through the stored positions; the next insert uses maxPosition.
    }
}

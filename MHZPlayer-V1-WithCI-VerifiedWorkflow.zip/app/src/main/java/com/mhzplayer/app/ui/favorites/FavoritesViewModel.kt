package com.mhzplayer.app.ui.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhzplayer.app.data.model.MediaItem
import com.mhzplayer.app.data.model.MediaType
import com.mhzplayer.app.data.repository.FavoritesRepository
import com.mhzplayer.app.data.repository.MediaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class FavoritesUiState(val items: List<MediaItem> = emptyList())

/** Section 20 — real Favorites list, backed by Room, joined against the live media library. */
class FavoritesViewModel(
    private val mediaRepository: MediaRepository,
    private val favoritesRepository: FavoritesRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(FavoritesUiState())
    val state: StateFlow<FavoritesUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                mediaRepository.audio,
                mediaRepository.video,
                favoritesRepository.observeFavoriteIds(),
            ) { audio, video, favorites ->
                val byId = (audio + video).associateBy { it.id to it.type }
                favorites.mapNotNull { byId[it.mediaId to MediaType.valueOf(it.type)] }
            }.collect { _state.value = FavoritesUiState(items = it) }
        }
    }

    fun clearAll() {
        viewModelScope.launch { state.value.items.forEach { favoritesRepository.toggle(it.id, it.type, true) } }
    }

    fun remove(item: MediaItem) {
        viewModelScope.launch { favoritesRepository.toggle(item.id, item.type, currentlyFavorite = true) }
    }
}

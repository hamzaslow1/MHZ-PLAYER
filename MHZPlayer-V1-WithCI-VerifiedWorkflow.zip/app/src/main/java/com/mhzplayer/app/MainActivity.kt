package com.mhzplayer.app

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.media3.exoplayer.ExoPlayer
import com.mhzplayer.app.ui.navigation.MhzNavGraph
import com.mhzplayer.app.ui.theme.MHZPlayerTheme

/**
 * Single-activity host. Playback itself lives in [com.mhzplayer.app.playback.PlaybackService]
 * (audio, background) and per-screen ExoPlayer instances (video); this Activity only hosts
 * the Compose navigation graph and bridges Android-only APIs like Picture-in-Picture, which
 * can only be triggered from an Activity.
 */
class MainActivity : ComponentActivity() {

    private var activeVideoPlayer: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as MHZPlayerApp
        app.locator.playerController.connect()

        setContent {
            MHZPlayerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MhzNavGraph(
                        onEnterPip = { player ->
                            activeVideoPlayer = player
                            enterPip()
                        },
                        onToggleFullscreen = { toggleFullscreen() },
                        onBrightness = { delta -> adjustBrightness(delta) },
                    )
                }
            }
        }
    }

    private fun toggleFullscreen() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        val hidden = controller.systemBarsBehavior == WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE &&
            !WindowInsetsCompat.toWindowInsetsCompat(window.decorView.rootWindowInsets).isVisible(WindowInsetsCompat.Type.systemBars())
        if (hidden) {
            controller.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun adjustBrightness(delta: Float) {
        val current = if (window.attributes.screenBrightness < 0f) 0.5f else window.attributes.screenBrightness
        window.attributes = window.attributes.apply { screenBrightness = (current + delta).coerceIn(0.05f, 1f) }
    }

    @SuppressLint("NewApi")
    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Section 19: if a video is actively playing when the user leaves, follow them into PiP.
        activeVideoPlayer?.let { if (it.isPlaying) enterPip() }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
    }

    override fun onDestroy() {
        (application as MHZPlayerApp).locator.playerController.release()
        super.onDestroy()
    }
}

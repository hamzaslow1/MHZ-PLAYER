# MHZ PLAYER proguard rules
-keep class com.mhzplayer.app.data.model.** { *; }
-keepattributes *Annotation*
